#!/bin/sh
# Sourced installer module; edit this file directly.

desktop_validate_obsidian_git_auto_enable() {
  case "${OBSIDIAN_GIT_AUTO_ENABLE-}" in
    true|false) ;;
    *) installer_fatal "OBSIDIAN_GIT_AUTO_ENABLE must be exactly true or false" ;;
  esac
}

desktop_validate_obsidian_git_policy() {
  desktop_validate_obsidian_git_auto_enable
  : "${OBSIDIAN_GIT_REPOSITORY_URL:?desktop profile must define the Obsidian Git SSH repository}"
  : "${OBSIDIAN_GIT_REPOSITORY_BRANCH:?desktop profile must define the Obsidian branch}"
  : "${OBSIDIAN_GIT_DIRECTORY:?desktop profile must define the Obsidian checkout}"
  : "${OBSIDIAN_GIT_SYNC_INTERVAL:?desktop profile must define the Obsidian sync interval}"
  [ "$OBSIDIAN_GIT_REPOSITORY_URL" = git@gitlab.com:core-assets/docs/obsidian-md.git ] &&
    [ "$OBSIDIAN_GIT_REPOSITORY_BRANCH" = mcr/main ] &&
    [ "$OBSIDIAN_GIT_DIRECTORY" = Syncthing/obsidian-md ] &&
    [ "$OBSIDIAN_GIT_SYNC_INTERVAL" = 1h ] ||
    installer_fatal "unapproved Obsidian repository, branch, checkout or hourly sync policy"
}

desktop_install_obsidian_repository() {
  desktop_validate_obsidian_git_policy
  managed_git_ssh_target_action clone-obsidian ||
    installer_fatal "cannot clone Obsidian vault with the managed GitLab SSH identity"
  desktop_log "cloned_obsidian_git_repository branch=${OBSIDIAN_GIT_REPOSITORY_BRANCH} path=${ACCOUNT_HOME}/${OBSIDIAN_GIT_DIRECTORY}"
}

desktop_install_browser_repository() {
  : "${BROWSER_NETSCAPE_REPOSITORY_URL:?desktop profile must define the browser Git SSH repository}"
  : "${BROWSER_NETSCAPE_REPOSITORY_BRANCH:?desktop profile must define the browser branch}"
  : "${BROWSER_NETSCAPE_DIRECTORY:?desktop profile must define the browser checkout}"
  [ "$BROWSER_NETSCAPE_REPOSITORY_URL" = git@gitlab.com:core-assets/helpers/netscape.git ] &&
    [ "$BROWSER_NETSCAPE_REPOSITORY_BRANCH" = mcr/main ] &&
    [ "$BROWSER_NETSCAPE_DIRECTORY" = Workspace/netscape ] ||
    installer_fatal "unapproved browser repository, branch or checkout"
  managed_git_ssh_target_action clone-netscape \
    --repository-url "$BROWSER_NETSCAPE_REPOSITORY_URL" \
    --repository-branch "$BROWSER_NETSCAPE_REPOSITORY_BRANCH" ||
    installer_fatal "cannot clone browser exports with the managed GitLab SSH identity"
  desktop_log "cloned_browser_repository branch=${BROWSER_NETSCAPE_REPOSITORY_BRANCH} path=${ACCOUNT_HOME}/${BROWSER_NETSCAPE_DIRECTORY}"
}

desktop_install_user_config() {
  : "${ACCOUNT_USERNAME:?ACCOUNT_USERNAME must be set}"
  : "${ACCOUNT_HOME:?ACCOUNT_HOME must be set}"

  desktop_log "installing primary account desktop config user=${ACCOUNT_USERNAME} home=${ACCOUNT_HOME}"
  # shellcheck disable=SC2016
  run_in_target "install Labwc desktop config for primary account" /bin/sh -c '
set -eu
account_user=$1
account_home=$2
kanshi_enabled=$3
copied_dirs=0
copied_files=0

case "$account_home" in
  /*) ;;
  *) printf "fatal: account home must be absolute\n" >&2; exit 1 ;;
esac
case "$account_home" in
  /|*..*|*//*|*[!ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._/-]*)
    printf "fatal: account home contains unsupported path syntax: %s\n" "$account_home" >&2
    exit 1
    ;;
esac

uid=$(id -u "$account_user")
gid=$(id -g "$account_user")

  install -d -m 0700 "$account_home" "$account_home/.config"
  install -d -m 0700 "$account_home/.cache"
  chown "$uid:$gid" "$account_home/.cache"
  for rel in \
    .profile.d \
    .config/labwc \
    .config/waypaper \
    .config/waybar \
    .config/waycal \
    .config/tomat \
    .config/cargo \
    .config/mise \
    .config/l3afpad \
    .config/foot \
    .config/git \
    .config/gitops \
    .config/gnote \
    .config/GottCode \
    .config/zathura \
    .local/share/GottCode \
    .local/share/dbus-1 \
    .cache/recoll \
    .config/Recoll.org \
    .recoll \
    .config/fontconfig \
    .config/kitty \
    .config/micro \
    .config/nano \
    .config/mpv \
    .config/nvim \
    .config/qalculate \
    .config/lxqt \
    .config/xarchiver \
    .config/task \
    .config/retroarch \
    .config/sleek \
    .config/tesseract \
    .config/xfce4 \
    .config/btop \
    .config/Code \
    .config/autostart \
    .config/chromium \
    .config/fzf \
    .config/fuzzel \
    .config/Thunar \
    .config/crystal-dock \
    .config/mako \
    .config/satty \
    .config/wayscriber \
    .config/swaylock \
    .config/wireplumber \
    .config/gtk-3.0 \
    .config/gtk-4.0 \
    .config/keepassxc \
    .config/microsoft-edge \
    .config/obsidian \
    .config/zoom \
    .config/qt5ct \
    .config/qt6ct \
    .config/systemd \
    .config/vim \
    .config/vivaldi \
    .config/xournalpp \
    .config/xdg-desktop-portal
  do
  src="/etc/skel-desktop/${rel}"
  dst="${account_home}/${rel}"
  [ -d "$src" ] || { printf "fatal: missing skel source: %s\n" "$src" >&2; exit 1; }
  install -d -m 0700 "$dst"
  cp -a "$src/." "$dst/"
  chown -R "$uid:$gid" "$dst"
  copied_dirs=$((copied_dirs + 1))
done
if [ ! -f /etc/skel-desktop/.config/wireplumber/wireplumber.conf.d/30-p15s-audio.conf ]; then
  rm -f "${account_home}/.config/wireplumber/wireplumber.conf.d/30-p15s-audio.conf"
fi
for user_systemd_dir in \
  "$account_home/.config/systemd" \
  "$account_home/.config/systemd/user" \
  "$account_home/.config/systemd/user"/*.d
do
  [ -d "$user_systemd_dir" ] || continue
  chmod 0700 "$user_systemd_dir"
  chown "$uid:$gid" "$user_systemd_dir"
done
if [ "$kanshi_enabled" = true ]; then
  src=/etc/skel-desktop/.config/kanshi
  dst="$account_home/.config/kanshi"
  [ -d "$src" ] && [ ! -L "$src" ] || exit 1
  [ ! -L "$dst" ] || exit 1
  install -d -m 0700 "$dst"
  cp -a "$src/." "$dst/"
  chown -R "$uid:$gid" "$dst"
  copied_dirs=$((copied_dirs + 1))
fi
if [ -d /etc/skel-desktop/.config/bazel ]; then
  src=/etc/skel-desktop/.config/bazel
  dst="${account_home}/.config/bazel"
  install -d -m 0700 "$dst"
  cp -a "$src/." "$dst/"
  chown -R "$uid:$gid" "$dst"
  copied_dirs=$((copied_dirs + 1))
fi
install -d -m 0700 "$account_home/.local/share/applications"
chown "$uid:$gid" "$account_home/.local/share/applications"
install -m 0600 /etc/skel-desktop/.local/share/applications/tutanota-desktop.desktop \
  "$account_home/.local/share/applications/tutanota-desktop.desktop"
chown "$uid:$gid" "$account_home/.local/share/applications/tutanota-desktop.desktop"
install -m 0600 /etc/skel-desktop/.local/share/applications/micro.desktop \
  "$account_home/.local/share/applications/micro.desktop"
chown "$uid:$gid" "$account_home/.local/share/applications/micro.desktop"
for private_dir in \
  "$account_home/.local/share/task" \
  "$account_home/.local/share/task/hooks" \
  "$account_home/Syncthing" \
  "$account_home/Syncthing/micro" \
  "$account_home/Syncthing/keepassxc" \
  "$account_home/Syncthing/keepassxc/backups"
do
  install -d -m 0700 "$private_dir"
  chown "$uid:$gid" "$private_dir"
done
rm -f "$account_home/.config/labwc/xinitrc"
  for rel_file in .profile .bash_profile .bashrc .bash_aliases .zshenv .zprofile .zshrc .zlogout .zsh_aliases .dircolors .vimrc .config/kdiff3rc .config/kwalletrc .config/starship.toml .config/l3afpad/style.css .config/xdg-terminals.list .config/mimeapps.list .config/user-dirs.dirs Syncthing/.stignore; do
  src="/etc/skel-desktop/${rel_file}"
  dst="${account_home}/${rel_file}"
  [ -r "$src" ] || { printf "fatal: missing skel source: %s\n" "$src" >&2; exit 1; }
  file_mode=0600
  parent_mode=0700
  if [ "$rel_file" = Syncthing/.stignore ]; then
    file_mode=0600
    parent_mode=0700
  fi
  install -d -m "$parent_mode" "$(dirname "$dst")"
  install -m "$file_mode" "$src" "$dst"
  chown "$uid:$gid" "$dst"
  copied_files=$((copied_files + 1))
done
  chown "$uid:$gid" "$account_home" "$account_home/.config"
  chmod 0700 "$account_home" "$account_home/.config"
if [ -x /usr/bin/vivaldi-stable ]; then
  for vivaldi_dir in \
    "$account_home/.cache" \
    "$account_home/.cache/vivaldi" \
    "$account_home/.config/vivaldi"
  do
    install -d -m 0700 "$vivaldi_dir"
    chown "$uid:$gid" "$vivaldi_dir"
  done
fi
# Only normalize account-owned entries. Prune foreign-owned directories before
# descending or changing modes: NFS bind parents are root-owned and immutable,
# and their unmounted endpoints must retain mode 0000. -xdev alone is insufficient.
find -P "$account_home" -xdev ! -uid "$uid" -prune -o -type d -exec chmod 0700 {} +
find -P "$account_home" -xdev ! -uid "$uid" -prune -o -type f -perm /0100 -exec chmod 0700 {} +
find -P "$account_home" -xdev ! -uid "$uid" -prune -o -type f ! -perm /0100 -exec chmod 0600 {} +
# Unit files and drop-ins are data, never programs. Do not preserve execute
# bits from a copied/restored skeleton on Whisper or other user units.
find -P "$account_home/.config/systemd/user" -xdev ! -uid "$uid" -prune -o -type f -exec chmod 0600 {} +
zsh_path=$(command -v zsh 2>/dev/null || true)
if [ -n "$zsh_path" ]; then
  usermod -s "$zsh_path" "$account_user"
fi
account_shell=$(getent passwd "$account_user" | cut -d: -f7)
printf "desktop_account_config user=%s home=%s copied_dirs=%s copied_files=%s shell=%s\n" "$account_user" "$account_home" "$copied_dirs" "$copied_files" "$account_shell"
' sh "$ACCOUNT_USERNAME" "$ACCOUNT_HOME" "$(if desktop_kanshi_enabled; then printf true; else printf false; fi)"
  desktop_install_primary_account_calendar_stack
  run_in_target "synchronize primary account application launchers" \
    /usr/local/bin/labwc-sync-application-launchers "$ACCOUNT_USERNAME" "$ACCOUNT_HOME"
  desktop_bootstrap_primary_account_gpg_key
  desktop_install_obsidian_repository
  desktop_install_browser_repository
  desktop_log "installed primary account desktop config user=${ACCOUNT_USERNAME}"
}
