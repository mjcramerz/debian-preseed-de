#!/bin/sh
# Labwc desktop target verification helpers.

desktop_verify_required_commands() {
  # shellcheck disable=SC2016
  run_in_target "verify Labwc desktop commands" /bin/sh -c '
set -eu
required_checked=0
optional_checked=0
optional_missing=

check_required() {
  cmd=$1
  command -v "$cmd" >/dev/null 2>&1 || {
    printf "fatal: required desktop command is missing: %s\n" "$cmd" >&2
    exit 1
  }
  required_checked=$((required_checked + 1))
}

check_optional() {
  cmd=$1
  if command -v "$cmd" >/dev/null 2>&1; then
    optional_checked=$((optional_checked + 1))
    return 0
  fi
  optional_missing="${optional_missing:+$optional_missing }$cmd"
}

check_optional_alternative() {
  primary_cmd=$1
  shift
  for cmd in "$primary_cmd" "$@"; do
    if command -v "$cmd" >/dev/null 2>&1; then
      optional_checked=$((optional_checked + 1))
      return 0
    fi
  done
  optional_missing="${optional_missing:+$optional_missing }$primary_cmd"
}

for cmd in \
  browser-devtools \
  labwc \
  cage \
  slirp4netns \
  gtkgreet \
  greetd-power-action \
  labwc-greeter-output \
  labwc-greeter-power \
  labwc-greeter-session \
  labwc-session \
  labwc-autostart \
  labwc-admin-action \
  labwc-calendar \
  labwc-ocr \
  labwc-logout \
  labwc-fuzzel \
  labwc-computer-management \
  labwc-ai-copilots \
  labwc-ai-copilots-action \
  labwc-digital-assets \
  labwc-digital-assets-action \
  labwc-users-groups-menu \
  labwc-adb-menu \
  labwc-adb-action \
  labwc-maintenance-menu \
  labwc-podman-menu \
  labwc-external-drives \
  labwc-security-action \
  labwc-system-action \
  labwc-recovery-action \
  labwc-network-control-menu \
  labwc-network-control-action \
  labwc-firewall-menu \
  labwc-firewall-action \
  labwc-network-scan-menu \
  labwc-network-scan-action \
  labwc-remote-desktop \
  labwc-freerdp-askpass \
  labwc-run \
  labwc-main-menu \
  labwc-fzf-menu \
  labwc-window-switcher \
  wtype \
  labwc-terminal \
  labwc-bluetooth \
  labwc-brightness-control \
  labwc-power-settings \
  labwc-power-menu \
  wayland-info \
  labwc-managed-app \
  labwc-electron-app \
  labwc-wayland-app \
  labwc-qbittorrent \
  labwc-sync-application-launchers \
  labwc-keyboard-layout \
  labwc-capture \
  labwc-wayscriber-toggle \
  satty \
  wayscriber \
  systemctl \
  systemd-run \
  dbus-update-activation-environment \
  desktop-file-validate \
  grim \
  slurp \
  wf-recorder \
  wl-copy \
  khal \
  keepassxc \
  recoll \
  recollindex \
  fido2-token \
  mail \
  pkexec \
  eject \
  findmnt \
  lsblk \
  sync \
  udisksctl \
  lynis \
  rkhunter \
  chkrootkit \
  systemd-analyze \
  fwupdmgr \
  spectre-meltdown-checker \
  debsecan \
  debsums \
  ss \
  nmap \
  lua5.5 \
  luac5.5 \
  dumpcap \
  tshark \
  tcpdump \
  wireshark \
  clamscan \
  freshclam \
  fangfrisch \
  visudo \
  aa-easyprof \
  aa-enabled \
  aa-features-abi \
  aa-audit \
  aa-autodep \
  aa-genprof \
  aa-logprof \
  aa-remove-unknown \
  aa-unconfined \
  logrotate \
  rsyslogd \
  ip \
  ifup \
  ifdown \
  ifquery \
  nmcli \
  perl \
  python3 \
  flock \
  todoman \
  task \
  taskwarrior-tui \
  vdirsyncer \
  tesseract \
  notify-send \
  sendmail
do
  check_required "$cmd"
done

for cmd in \
  crystal-dock \
  zsh \
  starship \
  btop \
  brightnessctl \
  bluetoothctl \
  btmgmt \
  rfkill \
  ncdu \
  nmtui \
  fzf \
  wlr-randr \
  wlopm \
  wdisplays \
  waybar \
  bwrap \
  eglinfo \
  es2_info \
  vainfo \
  xdg-dbus-proxy \
  foot \
  footclient \
  kitty \
  fuzzel \
  labwc-health-notify \
  mako \
  makoctl \
  swaylock \
  swaybg \
  swayidle \
  wpctl \
  thunar \
  nnn \
  featherpad \
  focuswriter \
  gnote \
  liferea \
  gnumeric \
  kdiff3 \
  micro \
  nvim \
  labwc-tweaks \
  qalculate-qt \
  retroarch \
  qt6ct \
  vim \
  xournalpp \
  qimgv \
  zathura \
  xarchiver \
  nwg-look \
  pavucontrol \
  pwsh \
  powerprofilesctl \
  xdg-terminal-exec \
  ikhal \
  pipewire \
  wireplumber \
  wsdd
do
  check_optional "$cmd"
done
check_optional_alternative sdl-freerdp sdl-freerdp3

printf "desktop_command_verification required_checked=%s optional_checked=%s optional_missing=%s\n" \
  "$required_checked" \
  "$optional_checked" \
  "${optional_missing:-none}"
' sh
}

desktop_verify_staged_files() {
  # shellcheck disable=SC2016
  run_in_target "verify Labwc desktop staged file metadata" /bin/sh -c '
set -eu
fatal() {
  printf "fatal: %s\n" "$*" >&2
  exit 1
}

require_readable() {
  path=$1
  [ -r "$path" ] || fatal "staged desktop path is missing or unreadable: $path"
}

require_executable() {
  path=$1
  [ -x "$path" ] || fatal "staged desktop executable is missing: $path"
}

require_mode() {
  path=$1
  expected_mode=$2
  actual_mode=$(find -P "$path" -maxdepth 0 -printf "%m")
  [ "$actual_mode" = "$expected_mode" ] ||
    fatal "staged desktop path mode mismatch: $path expected=$expected_mode actual=$actual_mode"
}

require_absent() {
  path=$1
  [ ! -e "$path" ] && [ ! -L "$path" ] ||
    fatal "retired desktop path is still present: $path"
}


# No benchmarks during validation; the installer already performed --version
# with dropped privileges after validating both archive and member checksums.
for resctl_binary in resctl-bench rd-agent rd-hashd; do
  require_executable "/usr/local/bin/$resctl_binary"
  require_mode "/usr/local/bin/$resctl_binary" 755
done
require_readable /usr/local/share/doc/resctl-bench/INSTALLATION.json
require_readable /usr/local/share/doc/resctl-bench/release/SHA256SUMS

# Pinned fonts are already SHA-verified and atomically published by fonts.sh.
require_readable /etc/skel-desktop/.config/fontconfig/conf.d/60-labwc-terminal-fonts.conf
require_mode /etc/skel-desktop/.config/fontconfig/conf.d/60-labwc-terminal-fonts.conf 644
require_readable /etc/skel-desktop/.local/share/icons/terminal-fonts/current/release-manifest.json
[ -L /etc/skel-desktop/.local/share/icons/terminal-fonts/current ] ||
  fatal "skeleton font generation is not activated"
require_readable /etc/skel-desktop/.config/fontconfig/conf.d/61-microsoft-fonts.conf
require_mode /etc/skel-desktop/.config/fontconfig/conf.d/61-microsoft-fonts.conf 644
require_readable /etc/skel-desktop/.local/share/fonts/microsoft-fonts/current/release-manifest.json
[ -L /etc/skel-desktop/.local/share/fonts/microsoft-fonts/current ] ||
  fatal "skeleton Microsoft font generation is not activated"
require_absent /usr/local/libexec/installer-desktop-fonts

# Managed Git and diagnostics assets: no credential decryption during verification.
require_executable /usr/local/bin/gitops
require_mode /usr/local/bin/gitops 755
require_readable /usr/local/share/doc/managed-git/README.md
require_mode /usr/local/share/doc/managed-git/README.md 644
require_executable /usr/local/bin/git-ssh
require_mode /usr/local/bin/git-ssh 755
require_executable /usr/local/bin/debugsys
require_mode /usr/local/bin/debugsys 755
require_executable /usr/local/libexec/debugsys.py
require_mode /usr/local/libexec/debugsys.py 755
require_executable /usr/local/libexec/debugsys-initramfs
require_mode /usr/local/libexec/debugsys-initramfs 755
require_executable /usr/local/share/debugsys/initramfs/hook
require_mode /usr/local/share/debugsys/initramfs/hook 755
require_executable /usr/local/libexec/labwc-ssh-key-load
require_mode /usr/local/libexec/labwc-ssh-key-load 755
require_executable /usr/local/libexec/labwc-ssh-gpg-askpass
require_mode /usr/local/libexec/labwc-ssh-gpg-askpass 755
require_readable /etc/gitops/aliases.gitconfig
require_mode /etc/gitops/aliases.gitconfig 644
require_readable /etc/ssh/managed_git_known_hosts
require_mode /etc/ssh/managed_git_known_hosts 644
require_readable /usr/local/libexec/managed-ssh-checks
require_mode /usr/local/libexec/managed-ssh-checks 644
require_readable /etc/systemd/system/debugsys-boot-report.service
require_mode /etc/systemd/system/debugsys-boot-report.service 644
require_readable /etc/systemd/user/ssh-agent.socket.d/10-labwc-session.conf
require_mode /etc/systemd/user/ssh-agent.socket.d/10-labwc-session.conf 644
require_readable /etc/systemd/user/ssh-agent.service.d/10-labwc-session.conf
require_mode /etc/systemd/user/ssh-agent.service.d/10-labwc-session.conf 644
require_executable /usr/local/libexec/managed-ssh-install.py
require_mode /usr/local/libexec/managed-ssh-install.py 700
require_executable /usr/local/libexec/managed-ssh-install-askpass
require_mode /usr/local/libexec/managed-ssh-install-askpass 700
require_readable /etc/skel-desktop/.config/gitops/gitops.env
require_readable /etc/skel-desktop/.config/git/config
require_readable /etc/skel-desktop/.config/systemd/user/labwc-ssh-key-load.service

desktop_skeleton=/etc/skel-desktop
[ -d "$desktop_skeleton" ] && [ ! -L "$desktop_skeleton" ] ||
  fatal "desktop skeleton root is missing or unsafe: $desktop_skeleton"
[ "$(find -P "$desktop_skeleton" -maxdepth 0 -printf "%U:%G")" = 0:0 ] ||
  fatal "desktop skeleton root must be owned by root:root: $desktop_skeleton"
require_mode "$desktop_skeleton" 755
legacy_skeleton_parent=/etc/skel
legacy_skeleton_name=primary
require_absent "${legacy_skeleton_parent}/${legacy_skeleton_name}"
unset desktop_skeleton legacy_skeleton_name legacy_skeleton_parent

require_symlink_target() {
  path=$1
  expected_target=$2
  [ -L "$path" ] || fatal "managed desktop symlink is missing: $path"
  actual_target=$(readlink "$path")
  [ "$actual_target" = "$expected_target" ] ||
    fatal "managed desktop symlink target mismatch: $path expected=$expected_target actual=$actual_target"
}

readable_count=0
executable_count=0
for path in \
  /etc/default/labwc-desktop \
  /etc/pam.d/polkit-1 \
  /etc/pam.d/systemd-user \
  /etc/pam.d/greetd \
  /etc/pam.d/greetd-greeter \
  /etc/pam.d/swaylock \
  /usr/share/pam-configs/wtmpdb \
  /etc/greetd/config.toml \
  /etc/greetd/gtkgreet.css \
  /etc/greetd/gtkgreet-power.css \
  /etc/polkit-1/rules.d/00-admin-identities.rules \
  /etc/polkit-1/rules.d/03-labwc-power.rules \
  /etc/polkit-1/rules.d/05-active-local-gate.rules \
  /etc/polkit-1/rules.d/10-greetd-power.rules \
  /etc/polkit-1/rules.d/10-pkexec.rules \
  /etc/polkit-1/rules.d/20-login1-power.rules \
  /etc/polkit-1/rules.d/40-networkmanager.rules \
  /etc/polkit-1/rules.d/50-usb-policy.rules \
  /etc/polkit-1/rules.d/55-software-management.rules \
  /etc/polkit-1/rules.d/60-system-services-identity.rules \
  /etc/polkit-1/rules.d/70-hardware-peripherals.rules \
  /etc/fangfrisch.conf \
  /etc/apparmor/easyprof.conf \
  /etc/apparmor/logprof.conf \
  /etc/audit/plugins.d/syslog.conf \
  /etc/systemd/journald.conf.d/10-storage.conf \
  /etc/rsyslog.conf \
  /etc/rsyslog.d/15-audit.conf \
  /etc/rsyslog.d/20-auth.conf \
  /etc/rsyslog.d/25-usb.conf \
  /etc/rsyslog.d/30-apparmor.conf \
  /etc/rsyslog.d/31-apparmor-managed-modes.conf \
  /etc/rsyslog.d/35-storage.conf \
  /etc/rsyslog.d/37-whisper.conf \
  /etc/rsyslog.d/39-security-scanners.conf \
  /etc/rsyslog.d/40-nftables.conf \
  /etc/rsyslog.d/41-fuzzel.conf \
  /etc/rsyslog.d/42-adb.conf \
  /etc/rsyslog.d/43-managed-desktop-apps.conf \
  /etc/rsyslog.d/99-discard.conf \
  /etc/logrotate.conf \
  /etc/systemd/system/logrotate.timer.d/override.conf \
  /etc/logrotate.d/rsyslog \
  /etc/logrotate.d/audit \
  /etc/logrotate.d/auth \
  /etc/logrotate.d/usb \
  /etc/logrotate.d/apparmor \
  /etc/logrotate.d/apparmor-managed-modes \
  /etc/logrotate.d/storage \
  /etc/logrotate.d/whisper \
  /etc/logrotate.d/nftables \
  /etc/logrotate.d/security-notify \
  /etc/logrotate.d/security-scanners \
  /etc/logrotate.d/fuzzel \
  /etc/logrotate.d/adb \
  /etc/logrotate.d/managed-desktop-apps \
  /etc/tmpfiles.d/60-security-logs.conf \
  /etc/tmpfiles.d/65-audit-syslog.conf \
  /etc/systemd/system/rsyslog.service.d/30-managed-security-scanner-socket.conf \
  /usr/local/libexec/rsyslog-managed-security-socket \
  /etc/udev/rules.d/53-ledger-wallet.rules \
  /etc/tmpfiles.d/25-desktop-media-runtime.conf \
  /etc/systemd/system/managed-clamav-signature-update.service \
  /etc/systemd/system/managed-clamav-signature-update.timer \
  /etc/systemd/system/labwc-admin-action@.service \
  /etc/systemd/system/labwc-package-sleep-guard.service \
  /etc/systemd/system/sleep.target.d/50-package-lock-guard.conf \
  /etc/systemd/user/wireplumber.service.d/60-resource-class.conf \
  /usr/local/share/nmap/scripts/managed-admin-surface-policy.nse \
  /usr/local/share/nmap/scripts/managed-approved-services.nse \
  /usr/local/share/nmap/scripts/managed-database-exposure-policy.nse \
  /usr/local/share/nmap/scripts/managed-http-security-headers.nse \
  /usr/local/share/nmap/scripts/managed-name-resolution-policy.nse \
  /usr/local/share/nmap/scripts/managed-plaintext-service-policy.nse \
  /usr/local/share/nmap/scripts/managed-service-inventory.nse \
  /usr/local/share/nmap/scripts/managed-tls-service-policy.nse \
  /etc/xdg/mimeapps.list \
  /usr/share/glib-2.0/schemas/90-desktop-wsdd.gschema.override \
  /etc/mailname \
  /etc/aliases \
  /etc/apt/listchanges.conf \
  /etc/apt/apt.conf.d/60desktop-local-mail.conf \
  /etc/opt/chrome/policies/managed/telemetry.json \
  /etc/opt/chrome/policies/managed/security.json \
  /etc/opt/chrome/policies/managed/performance.json \
  /etc/opt/chrome/policies/recommended/defaults.json \
  /etc/chromium/policies/managed/telemetry.json \
  /etc/chromium/policies/managed/security.json \
  /etc/chromium/policies/managed/performance.json \
  /etc/chromium/policies/recommended/defaults.json \
  /etc/opt/edge/policies/managed/telemetry.json \
  /etc/opt/edge/policies/managed/security.json \
  /etc/opt/edge/policies/managed/performance.json \
  /etc/opt/edge/policies/recommended/defaults.json \
  /etc/vivaldi/policies/managed/telemetry.json \
  /etc/vivaldi/policies/managed/extensions.json \
  /etc/vivaldi/policies/managed/security.json \
  /etc/vivaldi/policies/managed/performance.json \
  /etc/vivaldi/policies/recommended/defaults.json \
  /opt/glibc/2.44-1/satty/.managed-release \
  /etc/systemd/user/dbus-broker.service.d/10-broker-hardening.conf \
  /etc/systemd/system/dbus-broker.service.d/60-stop-timeout.conf \
  /etc/systemd/user/dbus-broker.service.d/60-stop-timeout.conf \
  /etc/systemd/user/foot-server.service.d/10-labwc-session.conf \
  /etc/systemd/user/foot-server.socket.d/10-labwc-session.conf \
  /etc/systemd/user/mako.service.d/10-labwc-session.conf \
  /etc/systemd/user/hyprpolkitagent.service.d/10-labwc-session.conf \
  /etc/systemd/user/filter-chain.service.d/10-labwc-session.conf \
  /etc/systemd/user/wayscriber.service.d/10-labwc-session.conf \
  /etc/systemd/user/xdg-desktop-portal.service.d/10-labwc-session.conf \
  /etc/systemd/user/xdg-desktop-portal-gtk.service.d/10-labwc-session.conf \
  /etc/systemd/user/xdg-desktop-portal-wlr.service.d/10-labwc-session.conf \
  /etc/systemd/user/xdg-desktop-portal-lxqt.service.d/10-labwc-session.conf \
  /etc/skel-desktop/.gnupg/gpg-agent.conf \
  /etc/skel-desktop/.config/systemd/user/waybar.service \
  /etc/skel-desktop/.config/systemd/user/waybar.service.d/20-tray-compat.conf \
  /etc/skel-desktop/.config/systemd/user/waybar.service.d/60-resource-class.conf \
  /etc/skel-desktop/.config/systemd/user/crystal-dock.service.d/60-resource-class.conf \
  /etc/skel-desktop/.config/systemd/user/app-.scope.d/60-resource-class.conf \
  /etc/skel-desktop/.config/systemd/user/labwc-adb-server.service \
  /etc/skel-desktop/.config/systemd/user/llama-server.service \
  /etc/skel-desktop/.config/systemd/user/labwc-output-watch.service \
  /etc/skel-desktop/.config/systemd/user/labwc-mute-default-microphone.service \
  /etc/skel-desktop/.config/systemd/user/swaybg.service \
  /etc/skel-desktop/.config/systemd/user/swayidle.service \
  /etc/skel-desktop/.config/systemd/user/crystal-dock.service \
  /etc/skel-desktop/.config/systemd/user/labwc-plans.service \
  /etc/skel-desktop/.config/systemd/user/labwc-sync-application-launchers.service \
  /etc/skel-desktop/.config/systemd/user/labwc-sync-application-launchers.path \
  /etc/systemd/system/labwc-system-desktop-overrides.service \
  /etc/systemd/system/labwc-system-desktop-overrides.path \
  /etc/systemd/system/multi-user.target.wants/labwc-system-desktop-overrides.service \
  /etc/systemd/system/multi-user.target.wants/labwc-system-desktop-overrides.path \
  /etc/skel-desktop/.profile.d \
  /etc/systemd/system/greetd.service.d/20-labwc-vt.conf \
  /etc/systemd/system/bluetooth-controller-init.service \
  /etc/skel-desktop/.config/systemd/user/labwc-kwallet-portal.service \
  /etc/skel-desktop/.local/share/dbus-1/services/org.freedesktop.secrets.service \
  /etc/fonts/fonts.conf \
  /usr/local/share/labwc-greeter/rc.xml \
  /usr/local/share/labwc-greeter/autostart \
  /usr/share/wayland-sessions/labwc.desktop \
  /usr/share/applications/computer-management.desktop \
  /usr/share/applications/remote-desktop-management.desktop \
  /usr/local/share/applications/foot.desktop \
  /etc/skel-desktop/.config/labwc/rc.xml \
  /etc/skel-desktop/.config/labwc/menu.xml \
  /etc/skel-desktop/.config/labwc/autostart \
  /etc/skel-desktop/.config/labwc/shutdown \
  /etc/skel-desktop/.config/labwc/environment \
  /etc/skel-desktop/.config/labwc/environment.d/10-wayland.env \
  /etc/skel-desktop/.config/waypaper/config.ini \
  /etc/skel-desktop/.config/waypaper/keybindings.ini \
  /etc/skel-desktop/.config/waypaper/style.css \
  /etc/skel-desktop/.config/btop/btop.conf \
  /etc/skel-desktop/.config/fzf/default-opts \
  /etc/skel-desktop/.config/satty/config.toml \
  /etc/skel-desktop/.config/wayscriber/config.toml \
  /etc/skel-desktop/.config/satty/overrides.css \
  /etc/skel-desktop/.config/labwc/themerc-override \
  /etc/skel-desktop/.config/Code/User/settings.json \
  /etc/skel-desktop/.config/chromium/Default/Preferences \
  /etc/skel-desktop/.config/keepassxc/keepassxc.ini \
  /etc/skel-desktop/.config/microsoft-edge/Default/Preferences \
  /etc/skel-desktop/.config/obsidian/obsidian.json \
  /etc/skel-desktop/.config/Recoll.org/recoll.ini \
  /etc/skel-desktop/.recoll/recoll.conf \
  /etc/skel-desktop/.config/vivaldi/Default/Preferences \
  /etc/skel-desktop/.config/systemd/user/labwc-session.target \
  /etc/skel-desktop/.config/systemd/user/labwc-health-notify.service \
  /etc/skel-desktop/.config/systemd/user/labwc-health-notify.path \
  /etc/skel-desktop/.config/systemd/user/labwc-health-notify.timer
do
  require_readable "$path"
  readable_count=$((readable_count + 1))
done

require_mode /etc/systemd/system/labwc-admin-action@.service 644
require_mode /etc/systemd/system/labwc-package-sleep-guard.service 644
require_mode /etc/systemd/system/sleep.target.d/50-package-lock-guard.conf 644
require_mode /usr/local/libexec/greetd-power-action-root 755
grep -qx 'Requires=labwc-package-sleep-guard.service' /etc/systemd/system/sleep.target.d/50-package-lock-guard.conf ||
  fatal 'sleep.target does not require the package lock guard'
grep -qx 'Before=sleep.target' /etc/systemd/system/labwc-package-sleep-guard.service ||
  fatal 'package lock guard is not ordered before sleep.target'
for power_action in reboot poweroff; do
  for power_kind in service target; do
    legacy_power_unit="/etc/systemd/system/labwc-power-${power_action}.${power_kind}"
    [ ! -e "$legacy_power_unit" ] && [ ! -L "$legacy_power_unit" ] ||
      fatal "obsolete shutdown transaction remains installed: $legacy_power_unit"
  done
done
require_mode /etc/systemd/user/wireplumber.service.d/60-resource-class.conf 644
grep -Fxq 'Slice=session.slice' /etc/systemd/user/wireplumber.service.d/60-resource-class.conf ||
  fatal "WirePlumber session class is missing"
for background_directory in \
  /usr/share/backgrounds \
  /usr/share/backgrounds/desktop \
  /usr/share/backgrounds/login
do
  [ -d "$background_directory" ] && [ ! -L "$background_directory" ] ||
    fatal "managed background directory is missing or unsafe: $background_directory"
  require_mode "$background_directory" 755
  [ "$(find -P "$background_directory" -maxdepth 0 -printf "%U:%G")" = 0:0 ] ||
    fatal "managed background directory is not root-owned: $background_directory"
done
unset background_directory
for background_file in \
  /usr/share/backgrounds/desktop/wallpaper-1920x1080.png \
  /usr/share/backgrounds/login/lock-1920x1080.png \
  /usr/share/backgrounds/login/welcome-1920x1080.png
do
  [ -f "$background_file" ] && [ ! -L "$background_file" ] ||
    fatal "managed background file is missing or unsafe: $background_file"
  require_mode "$background_file" 644
done
unset background_file
helper_package=$(dpkg-query -S /usr/sbin/unix_chkpwd 2>/dev/null) ||
  fatal "unix_chkpwd is not owned by an installed package"
printf "%s\n" "$helper_package" |
  grep -Eq "^libpam-modules-bin(:[^:[:space:]]+)?: /usr/sbin/unix_chkpwd$" ||
  fatal "unix_chkpwd has an unexpected package owner: $helper_package"
shadow_group_entry=$(getent group shadow) ||
  fatal "required shadow group is missing"
shadow_gid=$(printf "%s\n" "$shadow_group_entry" | cut -d: -f3)
case "$shadow_gid" in
  ""|*[!0-9]*) fatal "shadow group gid is invalid: $shadow_gid" ;;
esac
for authentication_path in /etc/shadow /usr/sbin/unix_chkpwd; do
  [ -f "$authentication_path" ] && [ ! -L "$authentication_path" ] ||
    fatal "authentication path is missing or unsafe: $authentication_path"
done
[ "$(find -P /etc/shadow -maxdepth 0 -printf "%U:%G:%m")" = "0:$shadow_gid:640" ] ||
  fatal "/etc/shadow must be root:shadow mode 0640"
[ "$(find -P /usr/sbin/unix_chkpwd -maxdepth 0 -printf "%U:%G:%m")" = "0:$shadow_gid:2755" ] ||
  fatal "/usr/sbin/unix_chkpwd must be root:shadow mode 2755"
helper_mount_options=$(findmnt -n -o OPTIONS -T /usr/sbin/unix_chkpwd) ||
  fatal "cannot resolve unix_chkpwd mount options"
case ",$helper_mount_options," in
  *,nosuid,*) fatal "unix_chkpwd resides on a nosuid mount" ;;
esac
unset authentication_path helper_mount_options helper_package shadow_gid shadow_group_entry
require_mode /etc/skel-desktop/.config/systemd 700
require_mode /etc/skel-desktop/.config/systemd/user 700
require_mode /etc/systemd/user/dbus-broker.service.d/10-broker-hardening.conf 644
for path in /etc/systemd/user/*.d; do
  [ -d "$path" ] || continue
  require_mode "$path" 755
  for dropin_path in "$path"/*.conf; do
    [ -f "$dropin_path" ] || continue
    require_mode "$dropin_path" 644
  done
done
require_mode /etc/skel-desktop/.gnupg 700
require_mode /etc/skel-desktop/.gnupg/gpg-agent.conf 600
for path in /etc/skel-desktop/.config/systemd/user/*.d; do
  [ -d "$path" ] || continue
  require_mode "$path" 700
done
require_mode /etc/skel-desktop/.local/share/dbus-1 755
require_mode /etc/skel-desktop/.local/share/dbus-1/services 755
for path in /etc/skel-desktop/.local/share/dbus-1/services/*.service; do
  require_mode "$path" 644
done

for path in \
  /etc/opt/chrome/policies/managed/telemetry.json \
  /etc/opt/chrome/policies/managed/security.json \
  /etc/opt/chrome/policies/managed/performance.json \
  /etc/opt/chrome/policies/recommended/defaults.json \
  /etc/chromium/policies/managed/telemetry.json \
  /etc/chromium/policies/managed/security.json \
  /etc/chromium/policies/managed/performance.json \
  /etc/chromium/policies/recommended/defaults.json \
  /etc/opt/edge/policies/managed/telemetry.json \
  /etc/opt/edge/policies/managed/security.json \
  /etc/opt/edge/policies/managed/performance.json \
  /etc/opt/edge/policies/recommended/defaults.json \
  /etc/vivaldi/policies/managed/telemetry.json \
  /etc/vivaldi/policies/managed/extensions.json \
  /etc/vivaldi/policies/managed/security.json \
  /etc/vivaldi/policies/managed/performance.json \
  /etc/vivaldi/policies/recommended/defaults.json
do
  require_mode "$path" 644
done

require_mode /usr/local/bin/browser-devtools 755
require_mode /usr/local/libexec/install-browser-imports 755
require_mode /usr/local/share/browser-imports 700
require_mode /usr/local/share/browser-imports/noscript_data.txt 600
require_mode /usr/local/share/browser-imports/my-ubol-settings.json 600
require_mode /usr/local/share/browser-imports/PrivacyBadger_user_data-9_6_2026_1_50_43_PM.json 600
require_mode /usr/local/share/browser-imports/bookmark-coverage.json 600
require_mode /usr/local/share/browser-imports/BROWSER-IMPORTS.md 600

require_mode /etc/skel-desktop/.config/keepassxc 700
require_mode /etc/skel-desktop/.config/keepassxc/keepassxc.ini 600
require_mode /etc/skel-desktop/.config/Code/User/settings.json 600
require_mode /etc/skel-desktop/.config/chromium/Default/Preferences 600
require_mode /etc/skel-desktop/.config/microsoft-edge/Default/Preferences 600
require_mode /etc/skel-desktop/.config/obsidian 700
require_mode /etc/skel-desktop/.config/obsidian/obsidian.json 600
require_mode /etc/skel-desktop/.config/vivaldi/Default/Preferences 600
require_mode /etc/skel-desktop/.config/Recoll.org 700
require_mode /etc/skel-desktop/.config/Recoll.org/recoll.ini 600
require_mode /etc/skel-desktop/.recoll 700
require_mode /etc/skel-desktop/.cache 700
require_mode /etc/skel-desktop/.cache/recoll 700
require_readable /etc/skel-desktop/Syncthing/.stignore
require_mode /etc/skel-desktop/Syncthing/.stignore 600
readable_count=$((readable_count + 1))

for path in \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/app.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/appearance.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/backlink.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/bookmarks.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/command-palette.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/community-plugins.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/core-plugins.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/daily-notes.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/graph.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/hotkeys.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/templates.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/types.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/snippets/managed-ux.css \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/themes/evergreen-notes/manifest.json \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/themes/evergreen-notes/theme.css \
  /etc/skel-desktop/Syncthing/obsidian-md/archive/index.md \
  /etc/skel-desktop/Syncthing/obsidian-md/daily/index.md \
  /etc/skel-desktop/Syncthing/obsidian-md/home.md \
  /etc/skel-desktop/Syncthing/obsidian-md/inbox/welcome.md \
  /etc/skel-desktop/Syncthing/obsidian-md/templates/daily-note-template.md \
  /etc/skel-desktop/Syncthing/obsidian-md/templates/note-template.md
do
  require_readable "$path"
  require_mode "$path" 600
  readable_count=$((readable_count + 1))
done

for path in \
  /etc/skel-desktop/Syncthing \
  /etc/skel-desktop/Syncthing/obsidian-md \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/snippets \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/themes \
  /etc/skel-desktop/Syncthing/obsidian-md/.obsidian/themes/evergreen-notes \
  /etc/skel-desktop/Syncthing/obsidian-md/.trash \
  /etc/skel-desktop/Syncthing/obsidian-md/archive \
  /etc/skel-desktop/Syncthing/obsidian-md/attachments \
  /etc/skel-desktop/Syncthing/obsidian-md/daily \
  /etc/skel-desktop/Syncthing/obsidian-md/inbox \
  /etc/skel-desktop/Syncthing/obsidian-md/templates
do
  require_mode "$path" 700
done

for path in \
  /usr/local/bin/labwc-greeter-session \
  /usr/local/bin/labwc-greeter-output \
  /usr/local/bin/labwc-greeter-power \
  /usr/local/libexec/labwc-greeter-client \
  /usr/local/sbin/greetd-power-action \
  /usr/local/bin/labwc-session \
  /usr/local/bin/labwc-autostart \
  /usr/local/bin/labwc-wallpaper-save \
  /usr/local/bin/labwc-admin-action \
  /usr/local/libexec/labwc-admin-action-root \
  /usr/local/libexec/labwc-admin-action-worker \
  /usr/local/libexec/greetd-power-action-root \
  /usr/local/libexec/labwc-logout-root \
  /usr/local/libexec/labwc-session-state \
  /usr/local/bin/labwc-calendar \
  /usr/local/libexec/labwc-calendar \
  /usr/local/bin/labwc-ocr \
  /usr/local/bin/labwc-logout \
  /usr/local/bin/labwc-fuzzel \
  /usr/local/bin/labwc-fuzzel-log \
  /usr/local/bin/labwc-computer-management \
  /usr/local/bin/labwc-fzf-menu \
  /usr/local/bin/labwc-window-switcher \
  /usr/local/bin/labwc-ai-copilots \
  /usr/local/bin/labwc-ai-copilots-action \
  /usr/local/libexec/labwc-ai-llama-server \
  /usr/local/libexec/labwc-ai-model-install-root \
  /usr/local/libexec/labwc-ai-model-info \
  /usr/local/bin/labwc-display-configuration \
  /usr/local/bin/labwc-digital-assets \
  /usr/local/bin/labwc-digital-assets-action \
  /usr/local/bin/labwc-users-groups-menu \
  /usr/local/bin/labwc-adb-menu \
  /usr/local/bin/labwc-adb-action \
  /usr/local/bin/labwc-maintenance-menu \
  /usr/local/bin/labwc-podman-menu \
  /usr/local/bin/labwc-external-drives \
  /usr/local/bin/labwc-security-action \
  /usr/local/bin/labwc-system-action \
  /usr/local/bin/labwc-recovery-action \
  /usr/local/bin/labwc-network-control-menu \
  /usr/local/bin/labwc-network-control-action \
  /usr/local/bin/labwc-firewall-menu \
  /usr/local/bin/labwc-firewall-action \
  /usr/local/bin/labwc-network-scan-menu \
  /usr/local/bin/labwc-network-scan-action \
  /usr/local/bin/labwc-remote-desktop \
  /usr/local/bin/labwc-freerdp-askpass \
  /usr/local/bin/telbot \
  /usr/local/bin/labwc-terminal \
  /usr/local/bin/labwc-bluetooth \
  /usr/local/bin/labwc-brightness-control \
  /usr/local/libexec/bluetooth-controller-init \
  /usr/local/bin/labwc-power-settings \
  /usr/local/libexec/labwc-output-watch \
  /usr/local/libexec/labwc-swaybg \
  /usr/local/libexec/labwc-swayidle \
  /usr/local/bin/labwc-health-notify \
  /usr/local/bin/labwc-managed-app \
  /usr/local/bin/labwc-electron-app \
  /usr/local/bin/labwc-wayland-app \
  /usr/local/libexec/labwc-wrap-desktop-files \
  /usr/local/bin/labwc-qbittorrent \
  /usr/local/bin/labwc-sync-application-launchers \
  /usr/local/bin/labwc-run \
  /usr/local/bin/labwc-main-menu \
  /usr/local/bin/labwc-lock \
  /usr/local/bin/labwc-power-menu \
  /usr/local/bin/labwc-keyboard-layout \
  /usr/local/bin/labwc-capture \
  /usr/local/bin/labwc-wayscriber-toggle \
  /usr/local/bin/satty \
  /usr/bin/wayscriber \
  /usr/local/libexec/apparmor-generate-rules \
  /usr/local/libexec/labwc-security-action-root \
  /usr/local/libexec/labwc-apparmor-policy-worker \
  /usr/local/libexec/labwc-apparmor-boot-state \
  /usr/local/libexec/labwc-system-action-root \
  /usr/local/libexec/labwc-recovery-action-root \
  /usr/local/libexec/labwc-network-control-action-root \
  /usr/local/libexec/labwc-firewall-action-root \
  /usr/local/libexec/labwc-network-scan-action-root \
  /usr/local/libexec/labwc-samsung-firmware-extract \
  /usr/local/libexec/managed-clamav-signature-update \
  /usr/local/libexec/satty/satty
do
  require_executable "$path"
  executable_count=$((executable_count + 1))
done

for path in \
  /etc/skel-desktop/.config/systemd/user/labwc-session-state@.service \
  /etc/skel-desktop/.config/systemd/user/labwc-session-restore.service
do
  require_readable "$path"
  require_mode "$path" 644
done

require_absent /usr/share/backgrounds/desktop/wallpapers.tar.gz
require_absent /usr/bin/Xwayland
if [ "$(dpkg-query -W -f='${Status}' xwayland 2>/dev/null || true)" = "install ok installed" ]; then
  printf '%s\n' 'fatal: public xwayland package must not be installed' >&2
  exit 1
fi
require_absent /etc/environment.d/90-labwc-session.conf
require_absent /etc/skel-desktop/.config/systemd/user/dbus-broker.service.d/10-broker-hardening.conf
require_absent /etc/systemd/user/default.target.wants/mpris-proxy.service
require_absent /etc/systemd/user/graphical-session.target.wants/foot-server.service
require_absent /etc/systemd/user/labwc-session.target.wants/waybar.service
require_absent /etc/skel-desktop/.config/systemd/user/labwc-session.target.wants/foot-server.service
require_absent /etc/skel-desktop/.config/systemd/user/xdg-desktop-portal-xapp.service.d/10-labwc-session.conf
for account_local_package_dropin in \
  filter-chain.service \
  foot-server.service \
  foot-server.socket \
  hyprpolkitagent.service \
  mako.service \
  pipewire.service \
  pipewire-pulse.service \
  pipewire.socket \
  pipewire-pulse.socket \
  wayscriber.service \
  wireplumber.service \
  xdg-desktop-portal.service \
  xdg-desktop-portal-gtk.service \
  xdg-desktop-portal-wlr.service \
  xdg-desktop-portal-lxqt.service
do
  require_absent "/etc/skel-desktop/.config/systemd/user/${account_local_package_dropin}.d/10-labwc-session.conf"
done
for legacy_user_unit in \
  waybar.service \
  waybar.service.d/20-tray-compat.conf \
  labwc-adb-server.service \
  llama-server.service \
  labwc-output-watch.service \
  labwc-mute-default-microphone.service \
  swaybg.service \
  kanshi.service \
  swayidle.service \
  crystal-dock.service \
  labwc-kwallet-portal.service \
  labwc-calendar-sync.service \
  labwc-calendar-sync.timer \
  labwc-sync-application-launchers.service \
  labwc-sync-application-launchers.path \
  managed-external-software-notify.service \
  managed-external-software-notify.path \
  whisper-record.service \
  whisper-transcribe.service \
  whisper-server.service
do
  require_absent "/etc/systemd/user/${legacy_user_unit}"
done

require_executable /usr/local/lib/android-sdk/platform-tools/adb
require_executable /usr/local/lib/android-sdk/platform-tools/fastboot
require_readable /usr/local/lib/android-sdk/platform-tools/source.properties
require_readable /usr/local/lib/android-sdk/platform-tools/.managed-release
require_symlink_target /usr/local/bin/adb ../lib/android-sdk/platform-tools/adb
require_symlink_target /usr/local/bin/fastboot ../lib/android-sdk/platform-tools/fastboot

require_executable /usr/local/lib/samloader/samloader
require_readable /usr/local/lib/samloader/.managed-release
require_symlink_target /usr/local/bin/samloader ../lib/samloader/samloader

require_readable /etc/udev/rules.d/51-android-debug-bridge.rules
require_readable /etc/udev/rules.d/52-samsung-download-mode.rules
require_readable /etc/udev/rules.d/53-ledger-wallet.rules

if [ -r /usr/share/dbus-1/system-services/org.freedesktop.nm_dispatcher.service ]; then
  nm_dispatcher_alias=/etc/systemd/system/dbus-org.freedesktop.nm-dispatcher.service
  nm_dispatcher_unit=
  require_readable /etc/systemd/system/NetworkManager.service.d/20-managed-dispatcher.conf
  require_readable /etc/systemd/system/NetworkManager-dispatcher.service.d/20-managed-persistent.conf
  if [ -r /usr/lib/systemd/system/NetworkManager-dispatcher.service ]; then
    nm_dispatcher_unit=/usr/lib/systemd/system/NetworkManager-dispatcher.service
  elif [ -r /lib/systemd/system/NetworkManager-dispatcher.service ]; then
    nm_dispatcher_unit=/lib/systemd/system/NetworkManager-dispatcher.service
  fi
  [ -n "$nm_dispatcher_unit" ] || fatal "NetworkManager dispatcher unit is missing"
  [ -L "$nm_dispatcher_alias" ] || fatal "NetworkManager dispatcher D-Bus alias is missing"
  [ "$(readlink -f "$nm_dispatcher_alias" 2>/dev/null || true)" = "$(readlink -f "$nm_dispatcher_unit" 2>/dev/null || true)" ] ||
    fatal "NetworkManager dispatcher D-Bus alias does not point to the vendor unit"
fi

printf "desktop_staged_file_metadata_verification readable=%s executable=%s\n" "$readable_count" "$executable_count"
' sh
}

desktop_verify_optional_staged_files() {
  # shellcheck disable=SC2016
  run_in_target "verify optional Labwc desktop staged files" /bin/sh -c '
set -eu
checked=0
missing=

check_optional_path() {
  path=$1
  if [ -e "$path" ]; then
    checked=$((checked + 1))
    return 0
  fi
  missing="${missing:+$missing }$path"
}

for path in \
  /usr/share/backgrounds/desktop/wallpaper-1920x1080.png \
  /usr/share/backgrounds/login/lock-1920x1080.png \
  /usr/share/backgrounds/login/welcome-1920x1080.png \
  /usr/share/backgrounds/other/regreet-000-greeter-purple.svg \
  /usr/share/backgrounds/other/wp2653774-black-and-blue-wallpaper-hd.png \
  /etc/skel-desktop/.config/waybar/config \
  /etc/skel-desktop/.config/waybar/style.css \
  /etc/skel-desktop/.config/featherpad/fp.conf \
  /etc/skel-desktop/.config/foot/foot.ini \
  /etc/skel-desktop/.config/gnote/addins/global.ini \
  /etc/skel-desktop/.config/GottCode/FocusWriter.conf \
  /etc/skel-desktop/.local/share/GottCode/FocusWriter/Themes/managed-word.theme \
  /etc/skel-desktop/.config/kitty/kitty.conf \
  /etc/skel-desktop/.config/kdiff3rc \
  /etc/skel-desktop/.config/micro/settings.json \
  /etc/skel-desktop/.config/nano/nanorc \
  /etc/skel-desktop/.config/xdg-terminals.list \
  /etc/skel-desktop/.config/nvim/init.lua \
  /etc/skel-desktop/.config/qalculate/qalc.cfg \
  /etc/skel-desktop/.config/qalculate/qalculate-qt.cfg \
  /etc/skel-desktop/.config/task/taskrc \
  /etc/skel-desktop/.config/retroarch/retroarch.cfg \
  /etc/skel-desktop/.config/tesseract/ocr-defaults.conf \
  /etc/skel-desktop/.config/tesseract/user-words/default.user-words \
  /etc/skel-desktop/.config/tesseract/user-patterns/default.user-patterns \
  /etc/skel-desktop/.config/vim/vimrc \
  /etc/skel-desktop/.vimrc \
  /etc/skel-desktop/.config/xfce4/helpers.rc \
  /etc/skel-desktop/.config/xfce4/xfconf/xfce-perchannel-xml/thunar.xml \
  /usr/share/xfce4/helpers/foot.desktop \
  /etc/skel-desktop/.profile \
  /etc/skel-desktop/.bash_profile \
  /etc/skel-desktop/.bashrc \
  /etc/skel-desktop/.bash_aliases \
  /etc/skel-desktop/.zshenv \
  /etc/skel-desktop/.zprofile \
  /etc/skel-desktop/.zshrc \
  /etc/skel-desktop/.zlogout \
  /etc/skel-desktop/.zsh_aliases \
  /etc/skel-desktop/.dircolors \
  /etc/skel-desktop/.config/starship.toml \
  /etc/skel-desktop/.config/fuzzel/base.ini \
  /etc/skel-desktop/.config/fuzzel/base-internal.ini \
  /etc/skel-desktop/.config/fuzzel/fuzzel.ini \
  /etc/skel-desktop/.config/fuzzel/fuzzel-internal.ini \
  /etc/skel-desktop/.config/fuzzel/menu.ini \
  /etc/skel-desktop/.config/fuzzel/menu-internal.ini \
  /etc/skel-desktop/.config/fuzzel/main-menu.ini \
  /etc/skel-desktop/.config/fuzzel/main-menu-internal.ini \
  /etc/skel-desktop/.config/Thunar/uca.xml \
  /etc/skel-desktop/.config/crystal-dock/labwc/appearance.conf \
  /etc/skel-desktop/.config/crystal-dock/labwc/panel_1.conf \
  /etc/xdg/crystal-dock/labwc/appearance.conf \
  /etc/xdg/crystal-dock/labwc/panel_1.conf \
  /usr/local/bin/labwc-show-desktop \
  /usr/share/applications/featherpad.desktop \
  /usr/share/applications/labwc-tweaks.desktop \
  /usr/share/applications/qt6ct.desktop \
  /usr/share/applications/retroarch.desktop \
  /usr/share/applications/show-desktop.desktop \
  /usr/local/bin/labwc-health-notify \
  /etc/skel-desktop/.config/mako/config \
  /etc/systemd/user/mako.service.d/10-labwc-session.conf \
  /etc/skel-desktop/.config/systemd/user/labwc-health-notify.service \
  /etc/skel-desktop/.config/systemd/user/labwc-health-notify.path \
  /etc/skel-desktop/.config/systemd/user/labwc-health-notify.timer \
  /etc/skel-desktop/.config/swaylock/config \
  /etc/skel-desktop/.config/gtk-3.0/settings.ini \
  /etc/skel-desktop/.config/gtk-4.0/settings.ini \
  /etc/xdg/gtk-3.0/settings.ini \
  /etc/xdg/gtk-4.0/settings.ini \
  /etc/skel-desktop/.config/qt6ct/qt6ct.conf \
  /etc/xdg/qt6ct/qt6ct.conf \
  /etc/skel-desktop/.config/kwalletrc \
  /etc/skel-desktop/.config/user-dirs.dirs \
  /etc/skel-desktop/.config/xournalpp/settings.xml \
  /etc/skel-desktop/.config/xdg-desktop-portal/portals.conf \
  /etc/xdg/xdg-desktop-portal/labwc-portals.conf \
  /etc/bluetooth/main.conf \
  /etc/chromium.d/90-performance-flags \
  /etc/skel-desktop/.config/systemd/user/labwc-calendar-sync.service \
  /etc/skel-desktop/.config/systemd/user/labwc-calendar-sync.timer \
  /etc/skel-desktop/.config/systemd/user/managed-external-software-notify.service \
  /etc/skel-desktop/.config/systemd/user/managed-external-software-notify.path \
  /etc/skel-desktop/.config/systemd/user/whisper-record.service \
  /etc/skel-desktop/.config/systemd/user/whisper-transcribe.service \
  /etc/skel-desktop/.config/systemd/user/whisper-server.service \
  /etc/systemd/system/bluetooth.service.d/override.conf \
  /etc/systemd/system/bluetooth-controller-init.service \
  /usr/local/libexec/bluetooth-controller-init \
  /usr/local/bin/labwc-bluetooth \
  /usr/share/applications/com.github.xournalpp.xournalpp.desktop \
  /usr/local/bin/labwc-managed-app \
  /usr/local/bin/labwc-electron-app \
  /usr/local/bin/labwc-wayland-app \
  /usr/local/libexec/labwc-wrap-desktop-files \
  /usr/local/bin/labwc-qbittorrent \
  /usr/local/bin/labwc-sync-application-launchers \
  /usr/share/applications/org.gnome.Gnote.desktop \
  /usr/share/glib-2.0/schemas/90-desktop-gnote.gschema.override \
  /usr/share/applications/net.sourceforge.liferea.desktop \
  /usr/share/glib-2.0/schemas/90-desktop-liferea.gschema.override \
  /usr/share/mime/packages/90-desktop-filetypes.xml \
  /etc/wireplumber/wireplumber.conf.d/10-disable-bluez-midi.conf \
  /etc/skel-desktop/.config/wireplumber/wireplumber.conf.d/10-disable-bluez-midi.conf
do
  check_optional_path "$path"
done
printf "desktop_optional_staged_file_verification checked=%s missing=%s\n" "$checked" "${missing:-none}"
' sh
}

desktop_verify_primary_user_files() {
  : "${ACCOUNT_USERNAME:?ACCOUNT_USERNAME must be set}"
  : "${ACCOUNT_HOME:?ACCOUNT_HOME must be set}"

  # shellcheck disable=SC2016
  run_in_target "verify Labwc primary account config" /bin/sh -c '
set -eu
fatal() {
  printf "fatal: %s\n" "$*" >&2
  exit 1
}

account_user=$1
account_home=$2
icon_theme=$3
uid=$(id -u "$account_user")
gid=$(id -g "$account_user")
required_checked=0
optional_checked=0
optional_missing=

check_required_owned() {
  path=$1
  [ -r "$path" ] || {
    printf "fatal: missing account desktop file: %s\n" "$path" >&2
    exit 1
  }
  owner=$(find -P "$path" -maxdepth 0 -printf "%U:%G")
  [ "$owner" = "$uid:$gid" ] || {
    printf "fatal: account desktop file owner mismatch for %s: %s\n" "$path" "$owner" >&2
    exit 1
  }
  required_checked=$((required_checked + 1))
}

check_required_owned_dir() {
  path=$1
  [ -d "$path" ] || {
    printf "fatal: missing account desktop directory: %s\n" "$path" >&2
    exit 1
  }
  owner=$(find -P "$path" -maxdepth 0 -printf "%U:%G")
  [ "$owner" = "$uid:$gid" ] || {
    printf "fatal: account desktop directory owner mismatch for %s: %s\n" "$path" "$owner" >&2
    exit 1
  }
  required_checked=$((required_checked + 1))
}

case "$icon_theme" in
  ""|*[!ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._+-]*)
    fatal "managed icon theme contains unsupported characters: ${icon_theme:-unset}"
    ;;
esac
[ -r "/usr/share/icons/${icon_theme}/index.theme" ] ||
  fatal "managed icon theme is unavailable: ${icon_theme}"
check_optional_owned() {
  path=$1
  [ -r "$path" ] || {
    optional_missing="${optional_missing:+$optional_missing }$path"
    return 0
  }
  optional_checked=$((optional_checked + 1))
}

verify_skeleton_session_link() {
  unit=$1
  link="/etc/skel-desktop/.config/systemd/user/labwc-session.target.wants/${unit}"
  [ -L "$link" ] || fatal "skeleton user session enablement link is missing: ${unit}"
  link_target=$(readlink "$link")
  case "$link_target" in
    "../${unit}"|/usr/lib/systemd/user/*|/lib/systemd/user/*) ;;
    *) fatal "skeleton user session enablement link is unsafe for ${unit}: ${link_target}" ;;
  esac
  owner=$(find -P "$link" -maxdepth 0 -printf "%U:%G")
  [ "$owner" = 0:0 ] ||
    fatal "skeleton user session enablement link owner mismatch for ${unit}: ${owner}"
  required_checked=$((required_checked + 1))
}

verify_account_session_link() {
  unit=$1
  link="$account_home/.config/systemd/user/labwc-session.target.wants/${unit}"
  [ -L "$link" ] || fatal "primary account user session enablement link is missing: ${unit}"
  link_target=$(readlink "$link")
  case "$link_target" in
    "../${unit}"|/usr/lib/systemd/user/*|/lib/systemd/user/*) ;;
    *) fatal "primary account user session enablement link is unsafe for ${unit}: ${link_target}" ;;
  esac
  owner=$(find -P "$link" -maxdepth 0 -printf "%U:%G")
  [ "$owner" = "$uid:$gid" ] ||
    fatal "primary account user session enablement link owner mismatch for ${unit}: ${owner}"
  required_checked=$((required_checked + 1))
}


# The encrypted identity and sealed passphrase are both private account files.
check_required_owned "$account_home/.local/share/managed-ssh/private/id_git_ed25519"
[ ! -L "$account_home/.local/share/managed-ssh/private/id_git_ed25519" ] || fatal "symlinked managed Git file"
[ "$(find -P "$account_home/.local/share/managed-ssh/private/id_git_ed25519" -maxdepth 0 -printf "%m:%n")" = 600:1 ] || fatal "unsafe managed Git file metadata"
check_required_owned "$account_home/.local/share/managed-ssh/git-key-passphrase.gpg"
[ ! -L "$account_home/.local/share/managed-ssh/git-key-passphrase.gpg" ] || fatal "symlinked managed Git file"
[ "$(find -P "$account_home/.local/share/managed-ssh/git-key-passphrase.gpg" -maxdepth 0 -printf "%m:%n")" = 600:1 ] || fatal "unsafe managed Git file metadata"
check_required_owned "$account_home/.ssh/id_git_ed25519.pub"
[ ! -L "$account_home/.ssh/id_git_ed25519.pub" ] || fatal "symlinked managed Git file"
[ "$(find -P "$account_home/.ssh/id_git_ed25519.pub" -maxdepth 0 -printf "%m:%n")" = 600:1 ] || fatal "unsafe managed Git file metadata"
check_required_owned "$account_home/.config/gitops/gitops.env"
[ ! -L "$account_home/.config/gitops/gitops.env" ] || fatal "symlinked managed Git file"
[ "$(find -P "$account_home/.config/gitops/gitops.env" -maxdepth 0 -printf "%m:%n")" = 600:1 ] || fatal "unsafe managed Git file metadata"
check_required_owned "$account_home/.config/git/config"
[ ! -L "$account_home/.config/git/config" ] || fatal "symlinked managed Git file"
[ "$(find -P "$account_home/.config/git/config" -maxdepth 0 -printf "%m:%n")" = 600:1 ] || fatal "unsafe managed Git file metadata"
check_required_owned "$account_home/.config/systemd/user/labwc-ssh-key-load.service"
[ ! -L "$account_home/.config/systemd/user/labwc-ssh-key-load.service" ] || fatal "symlinked managed Git file"
[ "$(find -P "$account_home/.config/systemd/user/labwc-ssh-key-load.service" -maxdepth 0 -printf "%m:%n")" = 600:1 ] || fatal "unsafe managed Git file metadata"
check_required_owned_dir "$account_home/.local/share/managed-ssh"
[ ! -L "$account_home/.local/share/managed-ssh" ] || fatal "symlinked managed Git directory"
[ "$(find -P "$account_home/.local/share/managed-ssh" -maxdepth 0 -printf "%m")" = 700 ] || fatal "unsafe managed Git directory"
check_required_owned_dir "$account_home/.local/share/managed-ssh/private"
[ ! -L "$account_home/.local/share/managed-ssh/private" ] || fatal "symlinked managed Git directory"
[ "$(find -P "$account_home/.local/share/managed-ssh/private" -maxdepth 0 -printf "%m")" = 700 ] || fatal "unsafe managed Git directory"
check_required_owned_dir "$account_home/.ssh"
[ ! -L "$account_home/.ssh" ] || fatal "symlinked managed Git directory"
[ "$(find -P "$account_home/.ssh" -maxdepth 0 -printf "%m")" = 700 ] || fatal "unsafe managed Git directory"
check_required_owned_dir "$account_home/.config/gitops"
[ ! -L "$account_home/.config/gitops" ] || fatal "symlinked managed Git directory"
[ "$(find -P "$account_home/.config/gitops" -maxdepth 0 -printf "%m")" = 700 ] || fatal "unsafe managed Git directory"
verify_skeleton_session_link ssh-agent.socket
verify_account_session_link ssh-agent.socket
# Interactive decryption is on demand; do not race wallet/login prompts.
for ssh_home in /etc/skel-desktop "$account_home"; do
  ssh_link="$ssh_home/.config/systemd/user/labwc-session.target.wants/labwc-ssh-key-load.service"
  [ ! -e "$ssh_link" ] && [ ! -L "$ssh_link" ] || fatal "SSH unlock must not run at login"
done

for path in \
  "$account_home/.config/labwc/rc.xml" \
  "$account_home/.config/labwc/menu.xml" \
  "$account_home/.config/labwc/autostart" \
  "$account_home/.config/labwc/shutdown" \
  "$account_home/.config/labwc/environment" \
  "$account_home/.config/labwc/themerc-override" \
  "$account_home/.config/waypaper/config.ini" \
  "$account_home/.config/waypaper/keybindings.ini" \
  "$account_home/.config/waypaper/style.css" \
  "$account_home/.config/btop/btop.conf" \
  "$account_home/.config/wayscriber/config.toml" \
  "$account_home/.config/fzf/default-opts" \
  "$account_home/.config/Code/User/settings.json" \
  "$account_home/.config/chromium/Default/Preferences" \
  "$account_home/.config/keepassxc/keepassxc.ini" \
  "$account_home/.config/microsoft-edge/Default/Preferences" \
  "$account_home/.config/obsidian/obsidian.json" \
  "$account_home/Syncthing/.stignore" \
  "$account_home/Syncthing/obsidian-md/.obsidian/app.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/appearance.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/backlink.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/bookmarks.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/command-palette.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/community-plugins.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/core-plugins.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/daily-notes.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/graph.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/hotkeys.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/templates.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/types.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/snippets/managed-ux.css" \
  "$account_home/Syncthing/obsidian-md/.obsidian/themes/evergreen-notes/manifest.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/themes/evergreen-notes/theme.css" \
  "$account_home/Syncthing/obsidian-md/archive/index.md" \
  "$account_home/Syncthing/obsidian-md/daily/index.md" \
  "$account_home/Syncthing/obsidian-md/home.md" \
  "$account_home/Syncthing/obsidian-md/inbox/welcome.md" \
  "$account_home/Syncthing/obsidian-md/templates/daily-note-template.md" \
  "$account_home/Syncthing/obsidian-md/templates/note-template.md" \
  "$account_home/.config/Recoll.org/recoll.ini" \
  "$account_home/.recoll/recoll.conf" \
  "$account_home/.config/vivaldi/Default/Preferences" \
  "$account_home/.gnupg/gpg-agent.conf" \
  "$account_home/.config/systemd/user/labwc-session.target" \
  "$account_home/.config/systemd/user/labwc-health-notify.service" \
  "$account_home/.config/systemd/user/labwc-health-notify.path" \
  "$account_home/.config/systemd/user/labwc-health-notify.timer" \
  "$account_home/.config/systemd/user/labwc-plans.service" \
  "$account_home/.config/systemd/user/labwc-adb-server.service" \
  "$account_home/.config/systemd/user/llama-server.service" \
  "$account_home/.config/systemd/user/labwc-calendar-sync.service" \
  "$account_home/.config/systemd/user/labwc-calendar-sync.timer" \
  "$account_home/.config/systemd/user/labwc-sync-application-launchers.service" \
  "$account_home/.config/systemd/user/labwc-sync-application-launchers.path" \
  "$account_home/.config/systemd/user/labwc-kwallet-portal.service" \
  "$account_home/.config/systemd/user/labwc-mute-default-microphone.service" \
  "$account_home/.config/systemd/user/labwc-output-watch.service" \
  "$account_home/.config/systemd/user/swaybg.service" \
  "$account_home/.config/systemd/user/swayidle.service" \
  "$account_home/.config/systemd/user/crystal-dock.service" \
  "$account_home/.config/systemd/user/waybar.service" \
  "$account_home/.config/systemd/user/waybar.service.d/20-tray-compat.conf" \
  "$account_home/.config/systemd/user/waybar.service.d/60-resource-class.conf" \
  "$account_home/.config/systemd/user/crystal-dock.service.d/60-resource-class.conf" \
  "$account_home/.config/systemd/user/app-.scope.d/60-resource-class.conf" \
  "$account_home/.local/share/dbus-1/services/org.freedesktop.secrets.service" \
  "$account_home/.local/share/applications/org.keepassxc.KeePassXC.desktop" \
  "$account_home/.local/share/applications/waypaper.desktop" \
  "$account_home/.config/fontconfig/conf.d/60-labwc-terminal-fonts.conf" \
  "$account_home/.local/share/icons/terminal-fonts/current/release-manifest.json" \
  "$account_home/.local/share/icons/terminal-fonts/.cache-ready" \
  "$account_home/.config/fontconfig/conf.d/61-microsoft-fonts.conf" \
  "$account_home/.local/share/fonts/microsoft-fonts/current/release-manifest.json" \
  "$account_home/.local/share/fonts/microsoft-fonts/.cache-ready"
do
  check_required_owned "$path"
done

[ ! -e "$account_home/.config/systemd/user/xdg-desktop-portal-xapp.service.d/10-labwc-session.conf" ] ||
  fatal "retired XApp portal user drop-in is still present"
[ ! -e "$account_home/.config/systemd/user/dbus-broker.service.d/10-broker-hardening.conf" ] ||
  fatal "system-wide D-Bus broker hardening was copied into the desktop account"

for account_local_package_dropin in \
  filter-chain.service \
  foot-server.service \
  foot-server.socket \
  mako.service \
  hyprpolkitagent.service \
  pipewire.service \
  pipewire-pulse.service \
  pipewire.socket \
  pipewire-pulse.socket \
  wireplumber.service \
  filter-chain.service \
  wayscriber.service \
  xdg-desktop-portal.service \
  xdg-desktop-portal-gtk.service \
  xdg-desktop-portal-wlr.service \
  xdg-desktop-portal-lxqt.service
do
  account_dropin="$account_home/.config/systemd/user/${account_local_package_dropin}.d/10-labwc-session.conf"
  [ ! -e "$account_dropin" ] && [ ! -L "$account_dropin" ] ||
    fatal "primary account package-unit drop-in is still present: ${account_dropin}"
done

for optional_user_unit in \
  managed-external-software-notify.service \
  managed-external-software-notify.path \
  whisper-record.service \
  whisper-transcribe.service \
  whisper-server.service
do
  [ -r "/etc/skel-desktop/.config/systemd/user/${optional_user_unit}" ] || continue
  check_required_owned "$account_home/.config/systemd/user/${optional_user_unit}"
done

for session_unit in \
  labwc-output-watch.service \
  swaybg.service \
  swayidle.service \
  crystal-dock.service \
  labwc-mute-default-microphone.service \
  labwc-kwallet-portal.service \
  labwc-plans.service \
  labwc-sync-application-launchers.service \
  labwc-sync-application-launchers.path \
  foot-server.socket \
  mako.service \
  filter-chain.service \
  labwc-calendar-sync.timer \
  wayscriber.service \
  hyprpolkitagent.service \
  xdg-desktop-portal.service \
  xdg-desktop-portal-gtk.service \
  xdg-desktop-portal-wlr.service \
  xdg-desktop-portal-lxqt.service
do
  verify_skeleton_session_link "$session_unit"
  verify_account_session_link "$session_unit"
done
require_absent "$account_home/.config/systemd/user/labwc-session.target.wants/foot-server.service"
require_absent "$account_home/.config/systemd/user/labwc-session.target.wants/llama-server.service"
for independent_audio_unit in \
  pipewire.service \
  pipewire-pulse.service \
  pipewire.socket \
  pipewire-pulse.socket \
  wireplumber.service
do
  require_absent "/etc/systemd/user/${independent_audio_unit}.d/10-labwc-session.conf"
  require_absent "/etc/skel-desktop/.config/systemd/user/labwc-session.target.wants/${independent_audio_unit}"
  require_absent "$account_home/.config/systemd/user/labwc-session.target.wants/${independent_audio_unit}"
done
unset independent_audio_unit
if [ -r /etc/skel-desktop/.config/systemd/user/whisper-server.service ]; then
  verify_skeleton_session_link whisper-server.service
  verify_account_session_link whisper-server.service
fi
if [ -r /etc/skel-desktop/.config/systemd/user/managed-external-software-notify.path ]; then
  verify_skeleton_session_link managed-external-software-notify.path
  verify_account_session_link managed-external-software-notify.path
fi

for on_demand_or_triggered_unit in \
  codex-app-server.service \
  codex-app-server-proxy.service \
  codex-app-server.socket \
  labwc-adb-server.service \
  labwc-calendar-sync.service \
  labwc-compositor.service \
  labwc-health-notify.path \
  labwc-health-notify.service \
  labwc-health-notify.timer \
  llama-server.service \
  managed-external-software-notify.service \
  waybar.service \
  whisper-record.service \
  whisper-transcribe.service
do
  require_absent "/etc/skel-desktop/.config/systemd/user/labwc-session.target.wants/${on_demand_or_triggered_unit}"
  require_absent "$account_home/.config/systemd/user/labwc-session.target.wants/${on_demand_or_triggered_unit}"
done
unset on_demand_or_triggered_unit

for path in \
  "$account_home/Desktop" \
  "$account_home/Documents" \
  "$account_home/Downloads" \
  "$account_home/Music" \
  "$account_home/Pictures" \
  "$account_home/Public" \
  "$account_home/Templates" \
  "$account_home/Videos" \
  "$account_home/Workspace" \
  "$account_home/.cache" \
  "$account_home/.cache/recoll" \
  "$account_home/.config/Code" \
  "$account_home/.config/chromium" \
  "$account_home/.config/microsoft-edge" \
  "$account_home/.config/obsidian" \
  "$account_home/.config/vivaldi" \
  "$account_home/.gnupg" \
  "$account_home/.config/systemd" \
  "$account_home/.config/systemd/user" \
  "$account_home/.config/systemd/user/labwc-session.target.wants" \
  "$account_home/.local" \
  "$account_home/.local/share" \
  "$account_home/.local/share/applications" \
  "$account_home/.local/share/GottCode" \
  "$account_home/.local/share/GottCode/FocusWriter" \
  "$account_home/.local/share/GottCode/FocusWriter/Themes" \
  "$account_home/.local/share/dbus-1" \
  "$account_home/.local/share/dbus-1/services" \
  "$account_home/.recoll" \
  "$account_home/.local/share/task" \
  "$account_home/.local/share/task/hooks" \
  "$account_home/Syncthing" \
  "$account_home/Syncthing/keepassxc" \
  "$account_home/Syncthing/keepassxc/backups" \
  "$account_home/Syncthing/obsidian-md" \
  "$account_home/Syncthing/obsidian-md/.obsidian" \
  "$account_home/Syncthing/obsidian-md/.obsidian/snippets" \
  "$account_home/Syncthing/obsidian-md/.obsidian/themes" \
  "$account_home/Syncthing/obsidian-md/.obsidian/themes/evergreen-notes" \
  "$account_home/Syncthing/obsidian-md/.trash" \
  "$account_home/Syncthing/obsidian-md/archive" \
  "$account_home/Syncthing/obsidian-md/attachments" \
  "$account_home/Syncthing/obsidian-md/daily" \
  "$account_home/Syncthing/obsidian-md/inbox" \
  "$account_home/Syncthing/obsidian-md/templates"
do
  check_required_owned_dir "$path"
done

if command -v vivaldi-stable >/dev/null 2>&1; then
  for path in \
    "$account_home/.cache" \
    "$account_home/.cache/vivaldi" \
    "$account_home/.config/vivaldi"
  do
    check_required_owned_dir "$path"
  done
fi

[ "$(find -P "$account_home/.config/keepassxc" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: KeePassXC config directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.config/keepassxc/keepassxc.ini" -maxdepth 0 -printf "%m")" = 600 ] || {
  printf "fatal: KeePassXC config file mode is not 0600\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.config/Recoll.org" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: Recoll GUI configuration directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.config/Recoll.org/recoll.ini" -maxdepth 0 -printf "%m")" = 600 ] || {
  printf "fatal: Recoll GUI configuration file mode is not 0600\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.recoll" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: Recoll index configuration directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.cache" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: XDG cache directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.config/systemd" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: systemd user configuration directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.config/systemd/user" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: systemd user unit directory mode is not 0700\n" >&2
  exit 1
}
for user_dropin_dir in "$account_home/.config/systemd/user"/*.d; do
  [ -d "$user_dropin_dir" ] || continue
  [ "$(find -P "$user_dropin_dir" -maxdepth 0 -printf "%m")" = 700 ] || {
    printf "fatal: systemd user drop-in directory mode is not 0700: %s\n" "$user_dropin_dir" >&2
    exit 1
  }
done
[ "$(find -P "$account_home/.gnupg" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: GnuPG directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.gnupg/gpg-agent.conf" -maxdepth 0 -printf "%m")" = 600 ] || {
  printf "fatal: GnuPG agent configuration mode is not 0600\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.local/share/dbus-1" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: D-Bus user data directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.local/share/dbus-1/services" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: D-Bus user activation directory mode is not 0700\n" >&2
  exit 1
}
for service_file in "$account_home/.local/share/dbus-1/services"/*.service; do
  [ -f "$service_file" ] || continue
  [ "$(find -P "$service_file" -maxdepth 0 -printf "%m")" = 600 ] || {
    printf "fatal: D-Bus user activation file mode is not 0600: %s\n" "$service_file" >&2
    exit 1
  }
done
[ "$(find -P "$account_home/.config/systemd/user/labwc-session.target.wants" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: Labwc session user-unit enablement directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.cache/recoll" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: Recoll cache directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.local/share/task" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: Taskwarrior data directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/.local/share/task/hooks" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: Taskwarrior hooks directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/Syncthing/keepassxc" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: KeePassXC database directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/Syncthing/obsidian-md" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: Obsidian vault directory mode is not 0700\n" >&2
  exit 1
}
[ "$(find -P "$account_home/Syncthing/obsidian-md/.obsidian" -maxdepth 0 -printf "%m")" = 700 ] || {
  printf "fatal: Obsidian vault configuration directory mode is not 0700\n" >&2
  exit 1
}
for private_file in \
  "$account_home/.config/obsidian/obsidian.json" \
  "$account_home/Syncthing/.stignore" \
  "$account_home/Syncthing/obsidian-md/.obsidian/app.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/appearance.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/core-plugins.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/themes/evergreen-notes/manifest.json" \
  "$account_home/Syncthing/obsidian-md/.obsidian/themes/evergreen-notes/theme.css"
do
  [ "$(find -P "$private_file" -maxdepth 0 -printf "%m")" = 600 ] || {
    printf "fatal: managed Obsidian file mode is not 0600: %s\n" "$private_file" >&2
    exit 1
  }
done
for path in \
    "$account_home/.config/waybar/config" \
  "$account_home/.config/featherpad/fp.conf" \
  "$account_home/.config/foot/foot.ini" \
  "$account_home/.config/gnote/addins/global.ini" \
  "$account_home/.config/GottCode/FocusWriter.conf" \
  "$account_home/.local/share/GottCode/FocusWriter/Themes/managed-word.theme" \
  "$account_home/.config/kitty/kitty.conf" \
  "$account_home/.config/kdiff3rc" \
  "$account_home/.config/mimeapps.list" \
  "$account_home/.config/micro/settings.json" \
  "$account_home/.config/nano/nanorc" \
  "$account_home/.config/xdg-terminals.list" \
  "$account_home/.config/nvim/init.lua" \
  "$account_home/.config/qalculate/qalc.cfg" \
  "$account_home/.config/qalculate/qalculate-qt.cfg" \
  "$account_home/.config/task/taskrc" \
  "$account_home/.config/retroarch/retroarch.cfg" \
  "$account_home/.config/tesseract/ocr-defaults.conf" \
  "$account_home/.config/tesseract/user-words/default.user-words" \
  "$account_home/.config/tesseract/user-patterns/default.user-patterns" \
  "$account_home/.config/vim/vimrc" \
  "$account_home/.vimrc" \
  "$account_home/.config/xfce4/helpers.rc" \
  "$account_home/.config/xfce4/xfconf/xfce-perchannel-xml/thunar.xml" \
  "$account_home/.config/fuzzel/base.ini" \
  "$account_home/.config/fuzzel/base-internal.ini" \
  "$account_home/.config/fuzzel/fuzzel.ini" \
  "$account_home/.config/fuzzel/fuzzel-internal.ini" \
  "$account_home/.config/fuzzel/menu.ini" \
  "$account_home/.config/fuzzel/menu-internal.ini" \
  "$account_home/.config/fuzzel/main-menu.ini" \
  "$account_home/.config/fuzzel/main-menu-internal.ini" \
  "$account_home/.config/Thunar/uca.xml" \
  "$account_home/.config/crystal-dock/labwc/appearance.conf" \
  "$account_home/.config/crystal-dock/labwc/panel_1.conf" \
  "$account_home/.config/mako/config" \
  "$account_home/.config/swaylock/config" \
  "$account_home/.profile" \
  "$account_home/.profile.d" \
  "$account_home/.bash_profile" \
  "$account_home/.bashrc" \
  "$account_home/.bash_aliases" \
  "$account_home/.zshenv" \
  "$account_home/.zprofile" \
  "$account_home/.zshrc" \
  "$account_home/.zlogout" \
  "$account_home/.zsh_aliases" \
  "$account_home/.dircolors" \
  "$account_home/.config/starship.toml" \
  "$account_home/.config/gtk-3.0/settings.ini" \
  "$account_home/.config/gtk-4.0/settings.ini" \
  "$account_home/.config/vdirsyncer/config" \
  "$account_home/.local/share/applications/chromium.desktop" \
  "$account_home/.local/share/applications/com.microsoft.Edge.desktop" \
  "$account_home/.local/share/applications/vivaldi-stable.desktop" \
  "$account_home/.local/share/applications/code.desktop" \
  "$account_home/.local/share/applications/bitwarden.desktop" \
  "$account_home/.local/share/applications/obsidian.desktop" \
  "$account_home/.local/share/applications/postman.desktop" \
  "$account_home/.local/share/applications/sleek.desktop" \
  "$account_home/.local/share/applications/tutanota-desktop.desktop" \
  "$account_home/.local/share/applications/Zoom.desktop" \
  "$account_home/.local/share/applications/Filen.desktop" \
  "$account_home/.local/share/applications/discord.desktop" \
  "$account_home/.local/share/applications/ledger-live.desktop" \
  "$account_home/.local/share/applications/org.telegram.desktop.desktop" \
  "$account_home/.local/share/applications/mullvad-browser.desktop" \
  "$account_home/.config/khal/config" \
  "$account_home/.config/todoman/config.py" \
  "$account_home/.local/share/calendars/personal/displayname" \
  "$account_home/.local/share/calendars/tasks/displayname" \
  "$account_home/.config/qt6ct/qt6ct.conf" \
  "$account_home/.config/user-dirs.dirs" \
  "$account_home/.config/xournalpp/settings.xml" \
  "$account_home/.config/xdg-desktop-portal/portals.conf" \
  "$account_home/.config/kwalletrc"
do
  check_optional_owned "$path"
done

zsh_path=$(command -v zsh 2>/dev/null || true)
account_shell=$(getent passwd "$account_user" | cut -d: -f7)
shell_status=not-checked
if [ -n "$zsh_path" ]; then
  if [ "$account_shell" = "$zsh_path" ]; then
    shell_status=matches-zsh
  else
    shell_status=mismatch
  fi
fi

printf "desktop_primary_account_verification user=%s home=%s required_files=%s optional_files=%s optional_missing=%s shell=%s shell_status=%s\n" \
  "$account_user" \
  "$account_home" \
  "$required_checked" \
  "$optional_checked" \
  "${optional_missing:-none}" \
  "$account_shell" \
  "$shell_status"
' sh "$ACCOUNT_USERNAME" "$ACCOUNT_HOME" "${LABWC_ICON_THEME:-Papirus-Dark}"
}

desktop_verify_greeter_access() {
  : "${LABWC_GREETER_USER:?LABWC_GREETER_USER must be set}"

  # shellcheck disable=SC2016
  run_in_target "verify Labwc greeter seat and DRM access" /bin/sh -c '
set -eu
greeter_user=$1
checked=0
present=
missing=
greeter_groups=$(id -nG "$greeter_user")
wireplumber_dropin=/etc/systemd/user/wireplumber.service.d/20-no-root.conf
[ -f "$wireplumber_dropin" ] && [ ! -L "$wireplumber_dropin" ] || {
  printf "fatal: WirePlumber user-condition drop-in is missing or unsafe: %s\n" "$wireplumber_dropin" >&2
  exit 1
}
grep -Fxq 'ConditionUser=!root' "$wireplumber_dropin" &&
  grep -Fxq "ConditionUser=!${greeter_user}" "$wireplumber_dropin" || {
    printf "fatal: WirePlumber is not excluded from the greeter user manager: %s\n" "$greeter_user" >&2
    exit 1
  }

for unit in pipewire.socket pipewire.service pipewire-pulse.socket pipewire-pulse.service; do
  dropin="/etc/systemd/user/${unit}.d/20-no-greeter.conf"
  [ -f "$dropin" ] && [ ! -L "$dropin" ] &&
    grep -Fxq "ConditionUser=!${greeter_user}" "$dropin" || {
      printf "fatal: PipeWire greeter exclusion is missing or unsafe: %s\n" "$dropin" >&2
      exit 1
    }
done

for group_name in seat render video; do
  if ! getent group "$group_name" >/dev/null 2>&1; then
    missing="${missing:+$missing }$group_name"
    continue
  fi
  case " $greeter_groups " in
    *" $group_name "*) ;;
    *)
      printf "fatal: greeter user %s is missing required group %s\n" "$greeter_user" "$group_name" >&2
      exit 1
      ;;
  esac
  checked=$((checked + 1))
  present="${present:+$present }$group_name"
done

printf "desktop_greeter_access_verification user=%s checked=%s present=%s missing=%s\n" \
  "$greeter_user" \
  "$checked" \
  "${present:-none}" \
  "${missing:-none}"
' sh "$LABWC_GREETER_USER"
}

desktop_verify_user_resource_policy() {
  # shellcheck disable=SC2016
  run_in_target "verify Labwc user resource policy files" /bin/sh -c '
set -eu

for policy_file in "$@"; do
  [ -r "$policy_file" ] || {
    printf "fatal: missing desktop user resource policy file: %s\n" "$policy_file" >&2
    exit 1
  }
done

printf "desktop_user_resource_policy_verification slice=%s files=%s\n" user-1000 "$#"
' sh \
    /etc/systemd/system/user-1000.slice.d/50-resource-accounting.conf \
    /etc/systemd/system/user@.service.d/50-oom-score.conf \
    /etc/systemd/user.conf.d/50-resource-defaults.conf
}

desktop_verify_native_workspace_config() {
  # Validate the real installed packages and both copied configuration trees.
  # This checks configuration, not live compositor behavior. No extra daemon,
  # language module, Wayland connection or generated bytecode is required.
  # shellcheck disable=SC2016
  run_in_target "verify broker-free workspace and native switcher configuration" \
    /usr/bin/python3 -I -B -c '
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

def require(condition, message):
    if not condition:
        raise SystemExit(message)

for package, minimum in (("labwc", "0.20.2"), ("waybar", "0.15.0"), ("fuzzel", "1.11.0")):
    version = subprocess.check_output(["/usr/bin/dpkg-query", "-W", "-f=${Version}", package], text=True).strip()
    subprocess.run(["/usr/bin/dpkg", "--compare-versions", version, "ge", minimum], check=True)
root = Path("/")
for retired in ("usr/local/libexec/labwc-workspace-broker",
                "usr/local/libexec/labwc-workspace-wayland-adapter",
                "usr/local/bin/labwc-workspace-broker-client"):
    path = root / retired
    require(not path.exists() and not path.is_symlink(), "retired taskbar executable remains: " + retired)
config_roots = (root / "etc/skel-desktop/.config", root / sys.argv[1].lstrip("/") / ".config")
counts = []
for config in config_roots:
    for name in ("labwc/rc.xml", "waybar/config", "waybar/style.css"):
        text = (config / name).read_text()
        require("__INSTALLER_" not in text, "unresolved workspace configuration: " + name)
        require("labwc-workspace-broker" not in text, "retired broker reference in " + name)
    for relative in ("systemd/user/labwc-workspace-broker.service",
                     "systemd/user/labwc-session.target.wants/labwc-workspace-broker.service"):
        path = config / relative
        require(not path.exists() and not path.is_symlink(), "retired taskbar unit remains: " + str(path))
    for relative in ("systemd/user/waybar.service", "systemd/user/labwc-session-restore.service"):
        require("labwc-workspace-broker" not in (config / relative).read_text(), "retired dependency in " + relative)
    rc = ET.parse(config / "labwc/rc.xml").getroot()
    count = int(rc.findtext("desktops/number", "0"))
    counts.append(count)
    require(1 <= count <= 12, "unsupported workspace count")
    names = [node.text for node in rc.findall("desktops/names/name")]
    require(names == [str(number) for number in range(1, count + 1)], "workspace names/count mismatch")
    switchers = rc.findall("windowSwitcher")
    require(len(switchers) == 1, "expected exactly one native switcher")
    switcher = switchers[0]
    require(switcher.get("order") in ("focus", "age"), "invalid switcher order")
    require(all(switcher.get(k) in ("yes", "no") for k in ("preview", "outlines", "unshade")), "invalid switcher boolean")
    osd = switcher.find("osd")
    require(osd is not None and osd.get("show") == "yes", "native switcher OSD missing")
    require(osd.get("style") == "thumbnail", "native thumbnail switcher required; classic lists are not supported")
    require(osd.get("output") in ("all", "focused", "cursor"), "invalid OSD output")
    require(osd.get("thumbnailLabelFormat") == "%n \u2014 %T  %S  %o", "invalid switcher label")
    require(switcher.find("fields") is None, "classic list fields must not be configured")
    panel = [x for x in rc.findall("keyboard/keybind") if x.get("key") == "F13"]
    require(len(panel) == 1 and panel[0].get("onRelease") is None, "invalid native panel switcher binding")
    actions = panel[0].findall("action")
    require(len(actions) == 1 and actions[0].get("name") == "NextWindow"
            and actions[0].get("workspace") == "current"
            and actions[0].get("output") in ("all", "focused", "cursor")
            and actions[0].get("identifier") == "all"
            and actions[0].get("menu") is None, "panel must use the native thumbnail switcher")
    for key, action in (("A-Tab", "NextWindow"), ("A-S-Tab", "PreviousWindow")):
        bindings = [x for x in rc.findall("keyboard/keybind") if x.get("key") == key]
        require(len(bindings) == 1, "duplicate or absent " + key)
        actions = bindings[0].findall("action")
        require(len(actions) == 1 and actions[0].get("name") == action, "non-native " + key)
        require(actions[0].get("workspace") == "current", "non-local " + key)
        require(actions[0].get("output") in ("all", "focused", "cursor"), "invalid candidate output")
        require(actions[0].get("identifier") == "all", "invalid candidate application filter")
    bars = json.loads((config / "waybar/config").read_text())
    require(len(bars) == 2, "expected internal and external bars")
    for bar in bars:
        left = bar.get("modules-left", [])
        require(all(name in left for name in ("ext/workspaces", "custom/window-switcher", "custom/wayscriber")), "native switcher button missing")
        require(left.index("custom/window-switcher") == left.index("ext/workspaces") + 1
                and left.index("custom/wayscriber") == left.index("custom/window-switcher") + 1, "native switcher button order changed")
        click = bar["custom/window-switcher"].get("on-click", "")
        require(click.endswith(" -- labwc-window-switcher") and "--property=KillMode=control-group" in click
                and "--property=PartOf=labwc-session.target" in click, "native switcher launch contract changed")
        selected = list(bar.get("modules-left", [])) + list(bar.get("modules-center", [])) + list(bar.get("modules-right", []))
        seen = set()
        while selected:
            name = selected.pop()
            if name in seen:
                continue
            seen.add(name)
            if name.startswith("group/"):
                selected.extend(bar[name].get("modules", []))
        require("ext/workspaces" in seen and "group/apps" in seen, "workspace selector or launcher drawer missing")
        require(bar["ext/workspaces"].get("on-click") == "activate", "workspace selection disabled")
        require(bar["ext/workspaces"].get("all-outputs") is True and bar["ext/workspaces"].get("active-only") is False, "workspace selector scope changed")
        require(("wlr/taskbar" in seen) == (count == 1), "global task list enabled on multiple workspaces, or single-workspace tasks missing")
        require(not any(n.startswith(("group/workspace-taskbar", "custom/workspace-app-")) for n in bar), "retired grouped taskbar remains")
        taskbar = bar["wlr/taskbar"]
        require(taskbar.get("all-outputs") is False and taskbar.get("format") == "{icon}", "native taskbar output/icon policy changed")
        require(taskbar.get("on-click") == "minimize-raise" and taskbar.get("on-click-right") == "minimize-raise" and taskbar.get("on-click-middle") == "close", "native taskbar actions changed")
        require(not any(k in taskbar for k in ("current-workspace-only", "workspace-only", "all-workspaces")), "unsupported taskbar workspace option")
require(len(set(counts)) == 1, "account workspace count differs from skeleton")
print("desktop_workspace_config_verification native=current broker=absent taskbar=" + ("native-single-workspace" if counts[0] == 1 else "omitted-no-workspace-protocol"))
' "${ACCOUNT_HOME:?ACCOUNT_HOME must be set}"
}

desktop_verify_font_publications() {
  run_in_target "verify both pinned font publication trees" /usr/bin/python3 -I -c '
import hashlib
import json
import os
from pathlib import Path
import pwd
import stat
import sys
import xml.etree.ElementTree as ET

# BEGIN FONT PUBLICATION VERIFICATION
home, username, skel, cache = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4])
account = pwd.getpwnam(username)
if account.pw_uid == 0 or str(home) != account.pw_dir:
    raise ValueError("font verification account/home mismatch")
names = ("FiraCode", "NerdFontsSymbolsOnly", "ProFont", "MicrosoftAptosFonts", "MicrosoftLocalFonts")
policy = sorted([dict(name=name, url=sys.argv[5 + 2*i], sha256=sys.argv[6 + 2*i])
                 for i, name in enumerate(names)], key=lambda row: row["name"])
identity = hashlib.sha256(json.dumps({"schema": 1, "archives": policy}, sort_keys=True).encode()).hexdigest()
manifest = "release-manifest.json"
groups = (("icons/terminal-fonts", names[:3], "60-labwc-terminal-fonts.conf"),
          ("fonts/microsoft-fonts", names[3:], "61-microsoft-fonts.conf"))

def require(condition, message):
    if not condition:
        raise ValueError(message)

def checked(path, uid, gid, directory=False, mode=None):
    info = path.lstat()
    require((stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode))
            and (info.st_uid, info.st_gid) == (uid, gid)
            and not info.st_mode & 0o022, "unsafe font path: " + str(path))
    if not directory:
        require(info.st_nlink == 1, "hardlinked font file")
    if mode is not None:
        require(stat.S_IMODE(info.st_mode) in (mode if isinstance(mode, tuple) else (mode,)), "font mode mismatch: " + str(path))

def read(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        return stream.read()

def inventory(root, uid, gid):
    # The existing home privacy pass may tighten a previous user release.
    directory_mode = 0o755 if uid == 0 else (0o755, 0o700)
    file_mode = 0o644 if uid == 0 else (0o644, 0o600)
    checked(root, uid, gid, True, directory_mode)
    records = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in dirs:
            checked(Path(directory) / name, uid, gid, True, directory_mode)
        for name in files:
            path = Path(directory) / name
            checked(path, uid, gid, mode=file_mode)
            if path != root / manifest:
                records[path.relative_to(root).as_posix()] = hashlib.sha256(read(path)).hexdigest()
    return records

source = cache / "releases" / identity
checked(cache, 0, 0, True)
checked(cache / "releases", 0, 0, True)
source_files = inventory(source, 0, 0)
source_record = json.loads(read(source / manifest))
require(source_record == {"schema": 1, "archives": policy, "files": source_files}, "root font cache mismatch")
for target_home, uid, gid in ((skel, 0, 0), (home, account.pw_uid, account.pw_gid)):
    checked(target_home, uid, gid, True)
    for relative, archive_names, config_name in groups:
        base = target_home / ".local/share" / relative
        cursor = target_home
        for part in base.relative_to(target_home).parts:
            cursor /= part
            checked(cursor, uid, gid, True)
        checked(base / "releases", uid, gid, True, 0o755 if uid == 0 else (0o755, 0o700))
        current = base / "current"
        info = current.lstat()
        require(stat.S_ISLNK(info.st_mode) and (info.st_uid, info.st_gid) == (uid, gid), "unsafe current link")
        require(os.readlink(current) == "releases/" + identity, "wrong or escaping font generation")
        release = base / "releases" / identity
        require({p.name for p in release.iterdir()} == set(archive_names) | {manifest}, "wrong font archive group")
        records = inventory(release, uid, gid)
        expected = {name: digest for name, digest in source_files.items() if name.split("/", 1)[0] in archive_names}
        subset = [row for row in policy if row["name"] in archive_names]
        require(records == expected and json.loads(read(release / manifest)) ==
                {"schema": 1, "archives": subset, "files": expected}, "font content/manifest mismatch")
        for name in archive_names:
            require(any(path.startswith(name + "/") and Path(path).suffix.lower() in (".ttf", ".otf", ".ttc", ".otc")
                        for path in records), "font archive has no readable font")
        marker = base / ".cache-ready"
        checked(marker, uid, gid, mode=0o600)
        require(read(marker) == (identity + "\n").encode(), "font cache generation mismatch")
        config = target_home / ".config/fontconfig/conf.d" / config_name
        cursor = target_home
        for part in config.parent.relative_to(target_home).parts:
            cursor /= part
            checked(cursor, uid, gid, True)
        checked(config, uid, gid, mode=0o644 if uid == 0 else 0o600)
        content = read(config)
        require(content == read(skel / ".config/fontconfig/conf.d" / config_name), "fontconfig differs from managed skeleton")
        xml = ET.fromstring(content)
        require(xml.tag == "fontconfig" and len(xml) == 1 and xml[0].tag == "dir"
                and xml[0].attrib == {"prefix": "xdg"} and xml[0].text == relative + "/current", "wrong fontconfig directory")
print("desktop_font_verification terminal=3 microsoft=2 content=verified")
# END FONT PUBLICATION VERIFICATION
' "${ACCOUNT_HOME:?ACCOUNT_HOME must be set}" "${ACCOUNT_USERNAME:?ACCOUNT_USERNAME must be set}" \
    /etc/skel-desktop /var/cache/installer-desktop-fonts \
    "${LABWC_FONT_FIRACODE_URL:?}" "${LABWC_FONT_FIRACODE_SHA256:?}" \
    "${LABWC_FONT_SYMBOLS_URL:?}" "${LABWC_FONT_SYMBOLS_SHA256:?}" \
    "${LABWC_FONT_PROFONT_URL:?}" "${LABWC_FONT_PROFONT_SHA256:?}" \
    "${LABWC_FONT_APTOS_URL:?}" "${LABWC_FONT_APTOS_SHA256:?}" \
    "${LABWC_FONT_MICROSOFT_URL:?}" "${LABWC_FONT_MICROSOFT_SHA256:?}"
}

desktop_verify_kanshi_policy() {
  # shellcheck disable=SC2016
  run_in_target "verify conditional Kanshi package, files and activation" /bin/sh -eu -c '

set -eu
. /etc/default/labwc-desktop
home=$1
case "$home" in /*) ;; *) exit 1 ;; esac
case "${LABWC_ENABLE_KANSHI:-false}" in
  true|yes|1|on) enabled=true ;;
  false|no|0|off) enabled=false ;;
  *) printf "fatal: invalid Kanshi policy\n" >&2; exit 1 ;;
esac
absent() { [ ! -e "$1" ] && [ ! -L "$1" ]; }
if state=$(dpkg-query -W -f="\${db:Status-Status}" kanshi 2>/dev/null); then
  :
else
  query_status=$?
  [ "$query_status" -eq 1 ] || exit "$query_status"
  state=not-installed
fi
if [ "$enabled" = true ]; then
  [ "$state" = installed ]
  [ -x /usr/bin/kanshi ]
  [ -x /usr/local/libexec/labwc-kanshi ]
  for base in /etc/skel-desktop "$home"; do
    [ -f "$base/.config/kanshi/config" ]
    [ ! -L "$base/.config/kanshi/config" ]
    units="$base/.config/systemd/user"
    [ -f "$units/kanshi.service" ] && [ ! -L "$units/kanshi.service" ]
    [ -d "$units/kanshi.service.d" ] && [ ! -L "$units/kanshi.service.d" ]
    [ -f "$units/kanshi.service.d/60-resource-class.conf" ]
    [ ! -L "$units/kanshi.service.d/60-resource-class.conf" ]
    link="$units/labwc-session.target.wants/kanshi.service"
    [ -L "$link" ] && [ "$(readlink "$link")" = ../kanshi.service ]
    [ -e "$link" ]
  done
else
  case "$state" in not-installed) ;; *) exit 1 ;; esac
  for path in /usr/local/bin/kanshi /usr/bin/kanshi /bin/kanshi /usr/local/libexec/labwc-kanshi; do
    absent "$path"
  done
  for units in /etc/systemd/user /etc/skel-desktop/.config/systemd/user "$home/.config/systemd/user"; do
    absent "$units/kanshi.service"
    absent "$units/kanshi.service.d"
    for link in "$units"/*.wants/kanshi.service "$units"/*.requires/kanshi.service; do
      absent "$link"
    done
  done
fi
printf "desktop_kanshi_verification enabled=%s\n" "$enabled"

' sh "$ACCOUNT_HOME"
}

desktop_verify_target_staging() {
  desktop_verify_kanshi_policy
  desktop_verify_required_commands
  desktop_verify_staged_files
  desktop_verify_native_workspace_config
  desktop_verify_font_publications
  desktop_verify_optional_staged_files
  desktop_verify_greeter_access
  desktop_verify_primary_user_files
  desktop_verify_user_resource_policy
}
