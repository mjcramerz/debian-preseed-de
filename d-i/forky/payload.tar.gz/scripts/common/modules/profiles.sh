#!/bin/sh
# Sourced installer module; edit this file directly.

installer_profile_ssh_policy() (
  # Read only these two literal profile fields before the class/package plan is
  # frozen. Never source a complete desktop profile merely to select an addon.
  set -eu
  umask 077
  policy_seed=$1
  policy_file=$(mktemp "$(installer_runtime_state_dir)/profile-ssh.XXXXXX")
  trap 'rm -f -- "$policy_file"' 0
  trap 'exit 129' HUP
  trap 'exit 130' INT
  trap 'exit 143' TERM
  installer_fetch_seed_path "$policy_seed" \
    "$(installer_profile_env_path "$INSTALLER_HOST_PROFILE_ENV_DIR" "$INSTALLER_HOST_PROFILE_ENV_NAME")" \
    "$policy_file" 0600 || installer_fatal 'cannot fetch profile SSH policy'
  awk '
    /^SSH_SERVER_ENABLE=/ {
      if (++enable_count != 1 || $0 !~ /^SSH_SERVER_ENABLE="(true|false)"$/) exit 1
      enable = substr($0, 20, length($0) - 20)
      next
    }
    /^SSH_SERVER_PORT=/ {
      if (++port_count != 1 || $0 !~ /^SSH_SERVER_PORT="[0-9][0-9][0-9][0-9][0-9]"$/) exit 1
      port = substr($0, 18, length($0) - 18)
      if (port + 0 < 30000 || port + 0 > 40000) exit 1
      next
    }
    /^[[:space:]]*(export[[:space:]]+)?SSH_SERVER_(ENABLE|PORT)/ { exit 1 }
    END {
      if (enable_count != 1 || port_count != 1 || enable == "" || port == "") exit 1
      print enable "|" port
    }
  ' "$policy_file" || installer_fatal 'profile requires literal SSH_SERVER_ENABLE and SSH_SERVER_PORT (30000..40000)'
)

installer_profile_shared_family() {
  profile_name=$1

  if [ -n "${INSTALLER_HOST_PROFILE:-}" ] && [ "$profile_name" = "${INSTALLER_HOST_PROFILE}" ] && [ -n "${INSTALLER_HOST_FAMILY:-}" ]; then
    printf '%s\n' "${INSTALLER_HOST_FAMILY}"
    return 0
  fi

  case "$profile_name" in
    *-*) printf '%s\n' "${profile_name%%-*}" ;;
    *) return 1 ;;
  esac
}

installer_profile_shared_families() {
  profile_name=$1
  installer_profile_shared_family "$profile_name"
}

installer_profile_variant() {
  profile_name=$1

  case "$profile_name" in
    *-*) printf '%s\n' "${profile_name#*-}" ;;
    *) return 1 ;;
  esac
}

installer_validate_profile_component() {
  component_label=$1
  component_value=$2

  case "$component_value" in
    ''|*[!A-Za-z0-9_-]*)
      installer_fatal "${component_label} contains an invalid profile path component: ${component_value:-unset}"
      ;;
  esac
}

installer_profile_layout_family() {
  profile_name=$1
  profile_family=${2:-}

  if [ -z "$profile_family" ]; then
    profile_family=$(installer_profile_shared_family "$profile_name" 2>/dev/null || true)
  fi

  if [ -n "${INSTALLER_HOST_PROFILE:-}" ] &&
    [ "$profile_name" = "${INSTALLER_HOST_PROFILE}" ] &&
    [ -n "${INSTALLER_HOOK_FAMILY:-}" ]; then
    profile_family=$INSTALLER_HOOK_FAMILY
  fi

  case "$profile_family" in
    btrfs|vm) printf 'btrfs\n' ;;
    f2fs) printf 'f2fs\n' ;;
    *) return 1 ;;
  esac
}

installer_profile_override_metadata() {
  override_seed_base=$1
  override_profile_name=$2
  INSTALLER_PROFILE_OVERRIDE_ENV_DIR=
  INSTALLER_PROFILE_OVERRIDE_ENV_NAME=
  INSTALLER_PROFILE_OVERRIDE_VARIANT=
  INSTALLER_PROFILE_OVERRIDE_HOST_FAMILY=

  case "$override_profile_name" in
    override-*)
      override_class_name=${override_profile_name#override-}
      ;;
    *)
      return 1
      ;;
  esac

  [ -n "$override_class_name" ] || installer_fatal "profile override name is empty: ${override_profile_name:-unset}"

  profile_group=$(installer_group_for_purpose host-profile-override 2>/dev/null || true)
  [ -n "$profile_group" ] || installer_fatal "profile override group is unavailable while resolving ${override_profile_name}"
  installer_class_has_manifest_record "$profile_group" "$override_class_name" ||
    installer_fatal "profile override ${override_profile_name} is missing from classes/configs/profile.cfg"

  override_env_dir=$(installer_class_meta_value "$override_seed_base" "$profile_group" "$override_class_name" host_profile_prefix)
  override_host_family=$(installer_class_meta_value "$override_seed_base" "$profile_group" "$override_class_name" host_family)
  override_required_classes=$(installer_class_meta_value "$override_seed_base" "$profile_group" "$override_class_name" requires_classes)
  override_variant=
  override_role_group=

  for required_class in $override_required_classes; do
    installer_class_token_parts "$required_class" >/dev/null
    case "${INSTALLER_CLASS_TOKEN_GROUP:-}" in
      role)
        override_role_group=${INSTALLER_CLASS_TOKEN_GROUP}
        override_variant=${INSTALLER_CLASS_TOKEN_NAME}
        break
        ;;
    esac
  done

  [ -n "$override_env_dir" ] || installer_fatal "profile override ${override_profile_name} must define HostProfilePrefix in classes/configs/profile.cfg"
  [ -n "$override_host_family" ] || installer_fatal "profile override ${override_profile_name} must define HostFamily in classes/configs/profile.cfg"
  [ -n "$override_variant" ] || installer_fatal "profile override ${override_profile_name} must require a role/<name> class"

  override_role_variant=$(installer_class_meta_value "$override_seed_base" "${override_role_group:-role}" "$override_variant" host_variant)
  [ -n "$override_role_variant" ] || override_role_variant=$override_variant

  INSTALLER_PROFILE_OVERRIDE_ENV_DIR=$override_env_dir
  INSTALLER_PROFILE_OVERRIDE_ENV_NAME=$override_class_name
  INSTALLER_PROFILE_OVERRIDE_VARIANT=$override_role_variant
  INSTALLER_PROFILE_OVERRIDE_HOST_FAMILY=$override_host_family
}

installer_fetch_composite_env_paths() (
  # Keep all assembly variables/traps private. A failed fetch must never leave
  # a nonempty partial host.env which later callers mistake for a cached one.
  umask 077
  composite_seed_base=$1
  composite_dest_path=$2
  composite_mode=$3
  shift 3
  composite_fetched_any=false
  composite_fetched_paths=

  case "$composite_mode" in
    [0-7][0-7][0-7]|0[0-7][0-7][0-7]) ;;
    *) installer_fatal 'invalid composite environment mode' ;;
  esac
  [ ! -L "$composite_dest_path" ] &&
    { [ ! -e "$composite_dest_path" ] || [ -f "$composite_dest_path" ]; } ||
    installer_fatal "host env destination is not a regular file: ${composite_dest_path}"
  install -d -m 0700 "$(dirname "$composite_dest_path")" ||
    installer_fatal "cannot prepare host env directory: ${composite_dest_path}"
  composite_work=$(mktemp -d "${composite_dest_path}.parts.XXXXXX") ||
    installer_fatal "cannot stage host env: ${composite_dest_path}"
  composite_part_dest="${composite_work}/part"
  composite_staged="${composite_work}/host.env"
  # A terminated transport may leave its own nested temporary file. Remove
  # only our private mktemp workspace, including those interrupted-copy files.
  trap 'rm -rf -- "$composite_work"' 0
  trap 'exit 129' HUP
  trap 'exit 130' INT
  trap 'exit 143' TERM
  : >"$composite_staged" || installer_fatal 'cannot initialize staged host env'
  for composite_candidate in "$@"; do
    [ -n "$composite_candidate" ] || continue
    if ! installer_fetch_seed_path "$composite_seed_base" "$composite_candidate" "$composite_part_dest" 0600; then
      installer_fatal "failed to fetch required host env ${composite_candidate} into ${composite_dest_path}"
    fi
    [ -s "$composite_part_dest" ] || installer_fatal "empty required host env: ${composite_candidate}"
    /bin/sh -n "$composite_part_dest" >/dev/null 2>&1 ||
      installer_fatal "invalid shell syntax in required host env: ${composite_candidate}"
    case "$composite_candidate" in
      hosts/logging/observability.env)
        installer_load_logging_helpers "$composite_seed_base" &&
          installer_validate_logging_data "$composite_seed_base" "$composite_part_dest" "$composite_work" ||
          installer_fatal 'invalid shared logging data; host environment was not published'
        ;;
    esac
    { cat "$composite_part_dest" && printf '\n'; } >>"$composite_staged" ||
      installer_fatal "cannot append required host env: ${composite_candidate}"
    composite_fetched_any=true
    composite_fetched_paths="${composite_fetched_paths:+$composite_fetched_paths }$composite_candidate"
  done

  [ "$composite_fetched_any" = true ] || installer_fatal "failed to fetch host env into $composite_dest_path"
  /bin/sh -n "$composite_staged" >/dev/null 2>&1 || installer_fatal 'invalid composed host environment'
  # Explicit guards also work when a caller uses this function in an if/OR
  # list, where POSIX shells suppress errexit throughout the function body.
  chmod "$composite_mode" "$composite_staged" &&
    mv -f -- "$composite_staged" "$composite_dest_path" ||
    installer_fatal "cannot publish complete host env: ${composite_dest_path}"
  installer_info "fetched host env ${composite_dest_path} from:${composite_fetched_paths:+ ${composite_fetched_paths}}"
)

installer_append_host_profile_app_veth_overrides() (
  set -eu
  override_seed_base=$1
  override_profile_path=$2
  override_dest_path=$3
  override_work=$(mktemp)
  trap 'rm -f -- "$override_work" "$override_work.map"' EXIT
  installer_fetch_seed_path "$override_seed_base" "$override_profile_path" "$override_work" 0600 ||
    installer_fatal "failed to fetch host profile application network overrides"
  /bin/sh -n "$override_work" >/dev/null 2>&1 ||
    installer_fatal "invalid shell syntax in host profile application network overrides"
  awk '
    BEGIN {
      allowed["APP_VETH_IPV4_CIDR"] = 1
      allowed["APP_VETH_MAX_LEASES"] = 1
      allowed["APP_VETH_HOST_INTERFACE_PREFIX"] = 1
      allowed["APP_VETH_HOST_INTERFACE_SUFFIX"] = 1
      allowed["APP_VETH_PEER_INTERFACE_SUFFIX"] = 1
      allowed["APP_VETH_OVERRIDE"] = 1
    }
    /^[[:space:]]*(export[[:space:]]+)?APP_VETH_[A-Z0-9_]+[[:space:]]*=/ {
      line = $0
      position = index(line, "=")
      key = substr(line, 1, position - 1)
      sub(/^[[:space:]]*export[[:space:]]+/, "", key)
      sub(/^[[:space:]]+/, "", key)
      sub(/[[:space:]]+$/, "", key)
      if (!(key in allowed) || key in seen) exit 1
      seen[key] = 1
      value = substr(line, position + 1)
      sub(/[[:space:]]+$/, "", value)
      if (value !~ /^"[^"\\$`[:cntrl:]]*"$/) exit 1
      value = substr(value, 2, length(value) - 2)
      if (value != "") print key "=" value
      next
    }
    /^[[:space:]]*(export[[:space:]]+)?APP_VETH_/ { exit 1 }
  ' "$override_work" >"$override_work.map" ||
    installer_fatal "invalid application network override in host profile"
  cat "$override_work.map" >>"$override_dest_path" ||
    installer_fatal "cannot append host profile application network overrides"
  /bin/sh -n "$override_dest_path" >/dev/null 2>&1 ||
    installer_fatal "invalid composed host environment after application network overrides"
)

installer_fetch_host_env() {
  host_seed_base=$1
  host_profile=$2
  host_dest_path=$3
  host_mode=${4:-0600}
  host_profile_env_dir=
  host_profile_env_name=

  if [ -n "${INSTALLER_HOST_PROFILE:-}" ] &&
     [ "$host_profile" = "${INSTALLER_HOST_PROFILE}" ] &&
     [ -n "${INSTALLER_HOST_PROFILE_ENV_DIR:-}" ] &&
     [ -n "${INSTALLER_HOST_PROFILE_ENV_NAME:-}" ]; then
    host_family=${INSTALLER_HOST_FAMILY:-}
    host_variant=${INSTALLER_HOST_VARIANT:-}
    host_profile_env_dir=${INSTALLER_HOST_PROFILE_ENV_DIR}
    host_profile_env_name=${INSTALLER_HOST_PROFILE_ENV_NAME}
  else
    case "$host_profile" in
      override-*)
        installer_profile_override_metadata "$host_seed_base" "$host_profile"
        host_family=${INSTALLER_PROFILE_OVERRIDE_HOST_FAMILY}
        host_variant=${INSTALLER_PROFILE_OVERRIDE_VARIANT}
        host_profile_env_dir=${INSTALLER_PROFILE_OVERRIDE_ENV_DIR}
        host_profile_env_name=${INSTALLER_PROFILE_OVERRIDE_ENV_NAME}
        ;;
      *) installer_fatal "unsupported host profile: ${host_profile:-unset}" ;;
    esac
  fi

  [ -n "$host_family" ] || installer_fatal "unable to derive host family from profile: ${host_profile:-unset}"
  [ -n "$host_variant" ] || installer_fatal "unable to derive host variant from profile: ${host_profile:-unset}"
  [ -n "$host_profile_env_dir" ] || installer_fatal "unable to derive host profile env directory from profile: ${host_profile:-unset}"
  [ -n "$host_profile_env_name" ] || installer_fatal "unable to derive host profile env name from profile: ${host_profile:-unset}"
  installer_validate_profile_component "host family" "$host_family"
  installer_validate_profile_component "host variant" "$host_variant"
  installer_validate_profile_component "host profile env directory" "$host_profile_env_dir"
  installer_validate_profile_component "host profile env name" "$host_profile_env_name"

  host_layout_family=$(installer_profile_layout_family "$host_profile" "$host_family" 2>/dev/null || true)
  [ -n "$host_layout_family" ] || installer_fatal "unable to derive layout family from profile: ${host_profile:-unset}"
  installer_validate_profile_component "host layout family" "$host_layout_family"

  set -- \
    "$(installer_repo_join_var DIR_HOSTS_PROFILES shared-de.env)" \
    "$(installer_profile_env_path "$host_profile_env_dir" "$host_profile_env_name")" \
    "$(installer_repo_join_var DIR_HOSTS_INSTALLER hosting.env)" \
    "$(installer_repo_join_var DIR_HOSTS_INSTALLER identity.env)" \
    "$(installer_repo_join_var DIR_HOSTS_INSTALLER runtime.env)" \
    "$(installer_repo_join_var DIR_HOSTS_LOGGING observability.env)"

  case "$host_variant" in
    desktop)
      ;;
    server)
      installer_fatal "this repository installs desktop systems only"
      ;;
    *)
      installer_fatal "unsupported host profile variant: ${host_variant}"
      ;;
  esac

  set -- "$@" \
    "$(installer_repo_join_var DIR_HOSTS_INSTALLER layout.env)" \
    "$(installer_repo_join_var DIR_HOSTS_INSTALLER "${host_layout_family}.env")" \
    "$(installer_repo_join_var DIR_HOSTS_INSTALLER boot.env)"

  installer_fetch_composite_env_paths \
    "$host_seed_base" \
    "$host_dest_path" \
    "$host_mode" \
    "$@"
  installer_append_host_profile_app_veth_overrides \
    "$host_seed_base" \
    "$(installer_profile_env_path "$host_profile_env_dir" "$host_profile_env_name")" \
    "$host_dest_path"
}

installer_fetch_account_env() {
  account_seed_base=$1
  account_dest_path=$2
  account_mode=${3:-0600}

  installer_fetch_seed_path \
    "$account_seed_base" \
    "$(installer_repo_join_var DIR_HOSTS_INSTALLER account.env)" \
    "$account_dest_path" \
    "$account_mode" || installer_fatal "failed to fetch account env"
}
